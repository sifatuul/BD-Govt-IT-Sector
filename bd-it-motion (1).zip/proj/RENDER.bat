@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Installing packages...
  call npm install
)
echo Preparing SRT timing, fonts and SFX...
call npm run prep
echo Rendering with voiceover...
call npx remotion render src/index.ts Main out\video.mp4 --props=props-voiceover.json --codec=h264 --crf=18
echo Done: out\video.mp4
pause
