import React from "react";
import { Composition } from "remotion";
import { Main } from "./Main";
import { TOTAL_FRAMES } from "./anchors";
import { FPS } from "./timing";

export const Root: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL_FRAMES} fps={FPS} width={1920} height={1080} defaultProps={{ withVoiceover: false }} />
);
