// anchors.ts - every moment is derived from the SRT cues (timing.ts). No hand-typed frame numbers in scenes.
import { CUES, FPS } from "./timing";

export { FPS };
export const LEAD = 5; // visuals enter ~5 frames before the spoken word
const byN = (n: number) => CUES.find((c) => c.n === n)!;
export const cs = (n: number) => byN(n).s;
export const ce = (n: number) => byN(n).e;
/** frame at fraction f of cue n */
export const ev = (n: number, f = 0) => Math.round(cs(n) + (ce(n) - cs(n)) * f);

export const MAIN_END = CUES[CUES.length - 1].e + 1; // narration end = SRT end + 1 frame
export const CREDIT_FRAMES = 108; // 3.6 s ending credit scene (0 = no credit)
export const TOTAL_FRAMES = MAIN_END + CREDIT_FRAMES;
export const END_CUT = 9; // last band (finale -> credit): window [MAIN_END, MAIN_END+18], cut at +9 so the final spoken caption stays visible

// scene = [first cue]; boundaries sit on cue starts, the gap after a scene belongs to it
const defs: [string, number][] = [
  ["hook", 1], ["office", 3], ["parents", 6], ["errors", 9], ["loop", 13], ["bribe", 15],
  ["mirror", 18], ["lab", 21], ["center", 25], ["apps", 30], ["gov", 32], ["servers", 36],
  ["need", 42], ["p1", 44], ["p2", 47], ["p3", 51], ["finale", 56],
];
export type SceneKey = (typeof defs)[number][0];
export const SCENES: Record<string, { from: number; to: number }> & { credit: { from: number; to: number } } = {
  credit: { from: MAIN_END, to: TOTAL_FRAMES },
} as never;
defs.forEach(([k, c], i) => {
  const from = i === 0 ? 0 : cs(c);
  const to = i === defs.length - 1 ? MAIN_END : cs(defs[i + 1][1]);
  SCENES[k] = { from, to };
});
export const SCENE_LIST = defs.map(([k]) => ({ key: k, ...SCENES[k] }));
