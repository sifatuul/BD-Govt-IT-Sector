import React from "react";
import { theme, bn } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Cert, Ico, D } from "../graphics/g";

const C = theme.colors;
const Paper: React.FC<{ w: number; h: number; hl?: boolean }> = ({ w, h, hl }) => (
  <div style={{ width: w, height: h, borderRadius: 14, background: C.paper, boxShadow: `0 18px 36px -12px ${C.shadow}`, padding: 22, border: hl ? `4px solid ${C.accent}` : undefined }}>
    <div style={{ height: 16, width: "50%", borderRadius: 8, background: C.accentDim, marginBottom: 18 }} />
    {[0.9, 0.7, 0.8, 0.55, 0.75].map((x, i) => <div key={i} style={{ height: 10, width: `${x * 100}%`, borderRadius: 5, background: "rgba(20,32,26,0.2)", marginBottom: 14 }} />)}
  </div>
);

export const S01: React.FC = () => {
  const { T, frame } = useSc();
  const t1 = T(ev(1, 0) - LEAD), t2 = T(ev(1, 0.5) - LEAD), t3 = T(ev(2, 0) - LEAD);
  const dim = ip(T(ev(2, 0)), 0, 16, 1, 0.42);
  const link = ip(T(ev(2, 0.12)), 0, 24, 0, 1);
  const pulse = 1 + Math.sin(frame / 6) * 0.03;
  return (
    <>
      {/* calendar */}
      <In t={t1} y={0} x={-120} s={0.7} rot={-18} cfg={theme.spring.bouncy} fade={dim} style={{ left: 150, top: 300 }}>
        <Card w={420} h={470} glow="acc">
          <div style={{ height: 120, background: C.hero, display: "flex", alignItems: "center", justifyContent: "center" }}><Tx size={64}>সাল</Tx></div>
          <div style={{ display: "flex", justifyContent: "center", marginTop: 52 }}><Tx size={170} color={C.accent}>{bn(2020)}</Tx></div>
        </Card>
      </In>
      {/* profile + documents */}
      <In t={t2} y={50} fade={dim} style={{ left: 680, top: 270, width: 560, height: 540 }}>
        <div style={{ position: "absolute", left: 0, top: 0 }}><Chip text="student profile" mono size={34} color={C.accent} /></div>
        <In t={t2 - 6} rot={-8} x={-30} y={30} style={{ left: 20, top: 90 }}><Paper w={300} h={380} /></In>
        <In t={t2 - 12} rot={7} x={30} y={30} style={{ left: 200, top: 120 }}><Paper w={300} h={380} /></In>
        <In t={t2 - 18} rot={-1} y={40} style={{ left: 110, top: 150 }}><Paper w={300} h={380} hl /></In>
        <In t={t2 - 24} s={0.5} cfg={theme.spring.bouncy} style={{ left: 150, top: 520 }}><Chip text="documents" mono size={30} color={C.text} /></In>
      </In>
      {/* connector */}
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080}>
        <path d="M1160 540 C1230 540 1220 540 1290 540" stroke={C.hero} strokeWidth="6" strokeDasharray="14 12" fill="none" strokeLinecap="round" strokeDashoffset={(1 - link) * 120} opacity={link} />
      </svg>
      {/* certificate */}
      <In t={t3} y={60} x={140} s={0.7} rot={6} cfg={theme.spring.bouncy} style={{ left: 1250, top: 330 }}>
        <div style={{ transform: `scale(${pulse})`, filter: `drop-shadow(0 0 40px ${C.glowHero})` }}><Cert w={540} h={520} /></div>
      </In>
      <In t={T(ev(2, 0.3))} y={-20} s={0.5} cfg={theme.spring.bouncy} style={{ left: 1480, top: 244 }}><Chip text="জরুরি" size={46} color={C.hero} fill="rgba(244,42,65,0.2)" /></In>
      <In t={T(ev(2, 0.62))} y={30} style={{ left: 1330, top: 800 }}><Chip text="online copy" mono size={38} color={C.accent} /></In>
      <In t={T(ev(2, 0.62))} s={0.4} y={0} style={{ left: 1260, top: 798 }}><Ico d={D.globe} size={58} color={C.accent} /></In>
    </>
  );
};
