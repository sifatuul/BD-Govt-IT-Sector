import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Gear, Ico, D, Server } from "../graphics/g";

const C = theme.colors;
export const S11: React.FC = () => {
  const { T, frame } = useSc();
  const o1 = T(ev(33, 0)), o2 = T(ev(34, 0)), o3 = T(ev(35, 0));
  const spin = frame * 3;
  const walk = ip(T(ev(35, 0.05)), 0, 90, 0, 1, theme.ease.inOut);
  return (
    <>
      {/* cue 32: previous govt vs present govt */}
      <In t={T(ev(32, 0) - LEAD)} out={o1} x={-100} style={{ left: 150, top: 310 }}>
        <Card w={700} h={420} border={C.hero}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16, paddingTop: 36 }}>
          <Chip text="আগের সরকার" size={44} color={C.dim} /><Ico d={D.trash} size={130} color={C.hero} /><Tx size={64} color={C.hero}>mega loot</Tx>
        </div></Card>
      </In>
      <In t={T(ev(32, 0.4) - LEAD)} out={o1} x={100} style={{ left: 1070, top: 310 }}>
        <Card w={700} h={420} glow="acc" border={C.accent}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16, paddingTop: 36 }}>
          <Chip text="বর্তমান সরকার" size={44} color={C.accent} /><Tx size={190} color={C.warn} style={{ lineHeight: 1 }}>?</Tx><Tx size={52}>কী করছে</Tx>
        </div></Card>
      </In>
      {/* cue 33: repairing the broken IT sector? */}
      <In t={T(ev(33, 0) - LEAD)} out={o2} s={0.3} cfg={theme.spring.bouncy} style={{ left: 660, top: 300 }}>
        <div style={{ width: 600, display: "flex", flexDirection: "column", alignItems: "center", gap: 20 }}>
          <div style={{ transform: `rotate(${spin}deg)` }}><Gear size={280} color={C.accent} /></div>
          <Tx size={92}>মেরামত?</Tx>
        </div>
      </In>
      {/* cue 34: the core servers are in bad shape */}
      <In t={T(ev(34, 0) - LEAD)} out={o3} y={50} style={{ left: 250, top: 290 }}>
        <div style={{ display: "flex", gap: 40 }}>
          {[0, 1, 2].map((i) => <div key={i} style={{ transform: `rotate(${(i - 1) * 4}deg) translateY(${i === 1 ? 18 : 0}px)`, opacity: i === 1 ? 0.7 : 1 }}><Server w={250} h={340} color={C.warn} led={i === 1 ? C.hero : C.warn} blink={frame + i * 5} /></div>)}
        </div>
      </In>
      <In t={T(ev(34, 0.45))} out={o3} x={80} style={{ left: 1170, top: 330 }}>
        <Card w={560} h={360} border={C.warn}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, paddingTop: 30 }}><Ico d={D.warn} size={120} color={C.warn} sw={3.2} /><Tx size={46} mono color={C.warn}>core IT infrastructure</Tx><Chip text="বেহাল দশা" size={52} color={C.hero} /></div></Card>
      </In>
      {/* cue 35: walking the same road */}
      <In t={T(ev(35, 0) - LEAD)} y={40} style={{ left: 0, top: 0, width: 1920, height: 1080 }}>
        <div style={{ position: "absolute", left: 120, top: 520, width: 1680, height: 150, borderRadius: 24, background: "#243A31", border: `3px solid ${C.line}` }}>
          <div style={{ position: "absolute", left: 20, right: 20, top: 70, height: 8, background: `repeating-linear-gradient(90deg, ${C.warn} 0 50px, transparent 50px 90px)`, opacity: 0.8 }} />
        </div>
        <div style={{ position: "absolute", left: 700 + walk * 640, top: 320 }}><Chip text="আগের সরকার" size={42} color={C.hero} /></div>
        <div style={{ position: "absolute", left: 770 + walk * 640, top: 405 }}><Ico d={D.user} size={110} color={C.hero} /></div>
        <div style={{ position: "absolute", left: 130 + walk * 640, top: 320 }}><Chip text="বর্তমান সরকার" size={42} color={C.accent} /></div>
        <div style={{ position: "absolute", left: 200 + walk * 640, top: 405 }}><Ico d={D.user} size={110} color={C.accent} /></div>
        <div style={{ position: "absolute", left: 560, top: 720, width: 800, textAlign: "center" }}><Chip text="একই পথ" size={64} color={C.hero} /></div>
      </In>
    </>
  );
};
