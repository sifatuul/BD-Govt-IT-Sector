import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Ico, D, Laptop, Padlock, Seal } from "../graphics/g";

const C = theme.colors;
const Tender: React.FC = () => (
  <div style={{ width: 200, height: 260, borderRadius: 14, background: C.paper, padding: 22, boxShadow: `0 18px 36px -12px ${C.shadow}` }}>
    <Tx size={34} color={C.ink} mono>tender</Tx>{[0.9, 0.7, 0.85, 0.6].map((w, i) => <div key={i} style={{ height: 10, width: `${w * 100}%`, borderRadius: 5, background: "rgba(20,32,26,0.22)", marginTop: 18 }} />)}
  </div>
);
export const S16: React.FC = () => {
  const { T, frame } = useSc();
  const o1 = T(ev(52, 0)), o2 = T(ev(53, 0)), o3 = T(ev(54, 0.05));
  const slide = ip(T(ev(51, 0.5)), 0, 30, 0, 1, theme.ease.inOut);
  const lines = ip(T(ev(53, 0.1)), 0, 60, 0, 1, theme.ease.soft);
  const ticks = (k: number) => T(ev(54, 0.15 + k * 0.22));
  return (
    <>
      {/* 51: tender out of the syndicate's hands */}
      <In t={T(ev(51, 0) - LEAD)} out={o1} x={-100} style={{ left: 130, top: 310 }}>
        <Card w={720} h={500} border={C.hero}><div style={{ padding: "26px 34px" }}>
          <Chip text="vendor syndicate" mono size={38} color={C.hero} />
          <div style={{ display: "flex", gap: 22, marginTop: 40, justifyContent: "center" }}>{[0, 1, 2].map((i) => <div key={i} style={{ width: 150, height: 190, borderRadius: 16, background: "#3A4C45", border: `2px solid ${C.line}`, display: "flex", alignItems: "center", justifyContent: "center", transform: `translateY(${i === 1 ? 24 : 0}px)` }}><Ico d={D.user} size={80} color={C.dim} /></div>)}</div>
          <div style={{ position: "absolute", left: 300 - slide * 0, top: 330, opacity: 1 - slide }}><Padlock size={100} /></div>
        </div></Card>
      </In>
      <In t={T(ev(51, 0.35) - LEAD)} out={o1} x={100} style={{ left: 1090, top: 310 }}>
        <Card w={720} h={500} border={C.accent} glow="acc"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20, paddingTop: 40 }}><Ico d={D.globe} size={130} color={C.accent} /><Tx size={60}>খোলা tender</Tx><Chip text="syndicate-এর বাইরে" size={40} color={C.accent} /></div></Card>
      </In>
      <div style={{ position: "absolute", left: 330 + slide * 800, top: 440 + Math.sin(slide * Math.PI) * -40, opacity: ip(T(ev(51, 0.45)), 0, 8, 0, 1) * (o1 > 0 ? ip(o1, 0, 9, 1, 0) : 1), transform: `rotate(${slide * 8}deg)` }}><Tender /></div>
      {/* 52: not foreign / blacklisted, but our own engineers */}
      <In t={T(ev(52, 0) - LEAD)} out={o2} x={-90} style={{ left: 130, top: 330 }}><Card w={470} h={400} border={C.hero}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, paddingTop: 36, position: "relative" }}><Ico d={D.globe} size={120} color={C.dim} /><Tx size={52}>বিদেশি company</Tx><div style={{ position: "absolute", right: -14, top: -16 }}><Ico d={D.cross} size={90} color={C.hero} sw={6} /></div></div></Card></In>
      <In t={T(ev(52, 0.2) - LEAD)} out={o2} y={50} style={{ left: 680, top: 330 }}><Card w={470} h={400} border={C.hero}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, paddingTop: 36, position: "relative" }}><Ico d={D.doc} size={120} color={C.dim} /><Tx size={44}>কালো তালিকাভুক্ত</Tx><Tx size={44}>ঠিকাদার</Tx><div style={{ position: "absolute", right: -14, top: -16 }}><Ico d={D.cross} size={90} color={C.hero} sw={6} /></div></div></Card></In>
      <In t={T(ev(52, 0.58) - LEAD)} out={o2} x={100} style={{ left: 1230, top: 310 }}><Card w={560} h={440} border={C.accent} glow="acc"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, paddingTop: 30 }}><div style={{ display: "flex", gap: 12 }}>{[0, 1, 2].map((i) => <Ico key={i} d={D.user} size={84} color={C.accent} />)}</div><Tx size={52}>বাংলাদেশের নিজস্ব</Tx><Chip text="software engineers" mono size={36} color={C.accent} /></div></Card></In>
      {/* 53: open source code */}
      <In t={T(ev(53, 0) - LEAD)} out={o3} y={50} style={{ left: 200, top: 300 }}><Card w={900} h={520} glow="acc"><div style={{ padding: "26px 34px", fontFamily: theme.fonts.mono, fontSize: 38 }}>
        <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>{[C.hero, C.warn, C.accent].map((c, i) => <div key={i} style={{ width: 16, height: 16, borderRadius: "50%", background: c }} />)}</div>
        {[["const", "system", "= build();"], ["open", "source", "= true;"], ["audit", "required", "= true;"], ["vendor", "syndicate", "= false;"]].map(([a, b, c], i) => <div key={i} style={{ color: C.text, width: `${Math.min(1, Math.max(0, lines * 4 - i)) * 100}%`, overflow: "hidden", whiteSpace: "nowrap", marginBottom: 26 }}><span style={{ color: C.cool }}>{a}</span> <span style={{ color: C.accent }}>{b}</span> {c}</div>)}
        <div style={{ width: 20, height: 40, background: C.accent, opacity: Math.sin(frame / 5) > 0 ? 1 : 0.2 }} />
      </div></Card></In>
      <In t={T(ev(53, 0.4) - LEAD)} out={o3} x={100} style={{ left: 1200, top: 340 }}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20 }}><Ico d={D.code} size={190} color={C.accent} sw={3} /><Chip text="open source" mono size={50} color={C.accent} /><Laptop w={300} /></div></In>
      {/* 54: independent technical audit, mandatory */}
      <In t={T(ev(54, 0.05) - LEAD)} y={50} style={{ left: 230, top: 290 }}>
        <Card w={1000} h={540} border={C.accent}><div style={{ padding: "30px 44px" }}>
          <Tx size={60} align="left">স্বাধীন technical audit</Tx>
          {["IT project", "tender", "system"].map((n, i) => { const t = ticks(i); const p = ip(t, 0, 10, 0, 1); return (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 26, marginTop: 34 }}>
              <div style={{ width: 80, height: 80, borderRadius: 18, border: `4px solid ${C.accent}`, background: p > 0.5 ? C.accent : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}>{p > 0.3 && <Ico d={D.check} size={56} color={C.bg} sw={7} />}</div>
              <Tx size={54} mono align="left">{n}</Tx>
            </div>); })}
        </div></Card>
      </In>
      <In t={T(ev(54, 0.55))} s={2.4} cfg={theme.spring.bouncy} style={{ left: 1300, top: 380 }}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}><Seal size={240} color={C.accent} /><Chip text="বাধ্যতামূলক" size={52} color={C.accent} /></div></In>
    </>
  );
};
