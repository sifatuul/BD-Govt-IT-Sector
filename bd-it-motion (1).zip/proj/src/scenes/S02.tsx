import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc, useSp } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Cert, Ico, D, Stamp } from "../graphics/g";

const C = theme.colors;
const Parishad: React.FC<{ w: number }> = ({ w }) => (
  <svg width={w} height={w * 0.78} viewBox="0 0 520 405">
    <rect x="0" y="372" width="520" height="22" rx="8" fill={C.panel2} />
    <rect x="40" y="350" width="440" height="24" fill="#5B6E66" /><rect x="60" y="328" width="400" height="24" fill="#6C7F77" />
    <path d="M30 120 L260 40 L490 120 Z" fill={C.hero} /><rect x="30" y="118" width="460" height="16" fill={C.heroDim} />
    {[80, 170, 260, 350, 440].map((x) => <rect key={x} x={x - 14} y="134" width="28" height="196" rx="6" fill="#D9D8C6" />)}
    <rect x="70" y="150" width="380" height="180" rx="6" fill="#B7C4BC" opacity="0.2" />
    {[120, 215, 305, 395].map((x) => <rect key={x} x={x - 22} y="190" width="44" height="64" rx="6" fill={C.warn} opacity="0.85" />)}
    <rect x="228" y="262" width="64" height="68" rx="6" fill={C.bg} />
    <line x1="260" y1="40" x2="260" y2="-6" stroke={C.text} strokeWidth="5" /><rect x="262" y="-6" width="52" height="34" fill={C.accentDim} /><circle cx="288" cy="11" r="10" fill={C.hero} />
  </svg>
);

export const S02: React.FC = () => {
  const { T, frame } = useSc();
  const sp = useSp();
  const tb = T(ev(3, 0) - LEAD), outB = T(ev(4, 0));
  const tOld = T(ev(4, 0) - LEAD), outOld = T(ev(5, 0));
  const tStamp = T(ev(4, 0.62));
  const stampS = ip(tStamp, 0, 8, 3.2, 1, theme.ease.out);
  const tForm = T(ev(5, 0) - LEAD);
  const tw = T(ev(5, 0.5));
  const click = T(ev(5, 0.28));
  return (
    <>
      {/* phase 1: the office + place chips */}
      <In t={tb} out={outB} y={60} style={{ left: 200, top: 350 }}><Parishad w={620} /></In>
      <In t={tb - 8} out={outB} y={20} style={{ left: 200, top: 262, width: 620 }}><Tx size={50}>ইউনিয়ন পরিষদ</Tx></In>
      {[["ঝিনাইদহ", 0.12], ["শৈলকূপা", 0.3], ["১৫ নং ফুলহরী", 0.5]].map(([txt, f], i) => (
        <In key={i} t={T(ev(3, f as number) - LEAD)} out={outB - i * 2} x={80} y={0} s={0.9} style={{ left: 980, top: 330 + i * 130 }}>
          <Card w={640} h={104} style={{ borderRadius: 52 }}><div style={{ display: "flex", alignItems: "center", gap: 22, padding: "0 34px", height: "100%" }}><Ico d={D.pin} size={58} color={C.hero} /><Tx size={50} align="left">{txt as string}</Tx></div></Card>
        </In>
      ))}
      {/* phase 2: old offline certificate gets cancelled */}
      <In t={tOld} out={outOld} x={160} y={20} s={0.75} rot={8} style={{ left: 680, top: 290 }}><Cert w={560} h={520} title="পুরোনো জন্ম নিবন্ধন" sub="offline" dim /></In>
      <In t={tOld - 4} out={outOld} x={-120} style={{ left: 130, top: 340 }}><Card w={470} h={400}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10, paddingTop: 26 }}><Ico d={D.doc} size={120} color={C.warn} /><Tx size={58}>পুরোনো</Tx><Chip text="offline" mono size={40} color={C.warn} /><Tx size={34} color={C.dim}>জন্ম নিবন্ধন</Tx></div></Card></In>
      <In t={T(ev(4, 0.8) - LEAD)} out={outOld} x={120} style={{ left: 1320, top: 340 }}><Card w={470} h={400} glow="acc" border={C.accent}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10, paddingTop: 26 }}><Ico d={D.globe} size={120} color={C.accent} /><Tx size={58}>নতুন</Tx><Chip text="online" mono size={40} color={C.accent} /><Tx size={34} color={C.dim}>আবেদন করতে হবে</Tx></div></Card></In>
      {tStamp > -3 && (
        <div style={{ position: "absolute", left: 640, top: 480, width: 640, display: "flex", justifyContent: "center", opacity: ip(tStamp, 0, 3, 0, 1) * (outOld > 0 ? ip(outOld, 0, 9, 1, 0, theme.ease.in) : 1), transform: `scale(${stampS})` }}>
          <Stamp text="বাতিল" size={150} />
        </div>
      )}
      {/* phase 3: online application form + the twist */}
      <In t={tForm} y={60} style={{ left: 380, top: 280 }}>
        <Card w={1160} h={540} glow="acc">
          <div style={{ height: 66, background: "rgba(7,19,15,0.6)", display: "flex", alignItems: "center", gap: 12, padding: "0 24px" }}>
            {[C.hero, C.warn, C.accent].map((c, i) => <div key={i} style={{ width: 16, height: 16, borderRadius: "50%", background: c }} />)}
            <div style={{ marginLeft: 24, flex: 1, height: 34, borderRadius: 17, background: "rgba(242,248,244,0.1)", display: "flex", alignItems: "center", padding: "0 18px" }}><Tx size={22} mono color={C.dim}>online জন্ম নিবন্ধন আবেদন</Tx></div>
          </div>
          <div style={{ padding: "34px 56px" }}>
            {[0.9, 0.72, 0.84].map((w, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 26, marginBottom: 28, opacity: sp(T(ev(5, 0.05 + i * 0.06)), theme.spring.snappy) }}>
                <div style={{ width: 150, height: 14, borderRadius: 7, background: C.dim, opacity: 0.6 }} /><div style={{ height: 58, width: `${w * 640}px`, borderRadius: 12, border: `2px solid ${C.line}`, background: "rgba(7,19,15,0.55)" }} />
              </div>
            ))}
            <div style={{ display: "flex", justifyContent: "flex-end", paddingRight: 30 }}>
              <div style={{ padding: "16px 54px", borderRadius: 16, background: C.accent, transform: `scale(${1 - 0.07 * Math.max(0, 1 - Math.abs(click - 3) / 3)})` }}><Tx size={40} color={C.bg}>আবেদন</Tx></div>
            </div>
          </div>
        </Card>
      </In>
      <In t={tw} y={-30} s={0.2} rot={-14} cfg={theme.spring.bouncy} style={{ left: 1290, top: 250 }}>
        <div style={{ transform: `rotate(${Math.sin(frame / 3) * 2}deg)` }}><Stamp text="twist!" size={104} color={C.hero} rot={-6} /></div>
      </In>
    </>
  );
};
