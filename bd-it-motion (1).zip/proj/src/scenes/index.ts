import React from "react";
import { S01 } from "./S01";
import { S02 } from "./S02";
import { S03 } from "./S03";
import { S04 } from "./S04";
import { S05 } from "./S05";
import { S06 } from "./S06";
import { S07 } from "./S07";
import { S08 } from "./S08";
import { S09 } from "./S09";
import { S10 } from "./S10";
import { S11 } from "./S11";
import { S12 } from "./S12";
import { S13 } from "./S13";
import { S14 } from "./S14";
import { S15 } from "./S15";
import { S16 } from "./S16";
import { S17 } from "./S17";

export const SCENE_COMPONENTS: Record<string, { C: React.FC; dy?: number }> = {
  hook: { C: S01 }, office: { C: S02 }, parents: { C: S03 }, errors: { C: S04 },
  loop: { C: S05 }, bribe: { C: S06 }, mirror: { C: S07 }, lab: { C: S08 },
  center: { C: S09 }, apps: { C: S10 }, gov: { C: S11 }, servers: { C: S12 },
  need: { C: S13 }, p1: { C: S14 }, p2: { C: S15 }, p3: { C: S16 }, finale: { C: S17 },
};
