import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Db, Ico, D, Note, Padlock, Server } from "../graphics/g";

const C = theme.colors;
const Eq: React.FC = () => <svg width="130" height="110" viewBox="0 0 48 40"><path d="M8 13 H40 M8 27 H40" stroke={C.warn} strokeWidth="6" strokeLinecap="round" /></svg>;

export const S07: React.FC = () => {
  const { T, frame } = useSc();
  const out1 = T(ev(19, 0)), out2 = T(ev(20, 0));
  const dbN = ["জন্ম নিবন্ধন", "NID", "passport", "bank"];
  return (
    <>
      {/* cue 18: the 100-taka bypass = the whole IT sector */}
      <In t={T(ev(18, 0) - LEAD)} out={out1} x={-100} style={{ left: 110, top: 300 }}>
        <div style={{ transform: `translateX(${(1 - ip(T(ev(18, 0.45)), 0, 22, 0, 1, theme.ease.inOut)) * 490}px)` }}><Card w={720} h={470} glow="acc"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 24, paddingTop: 36 }}>
          <Note w={360} />
          <svg width="520" height="120" viewBox="0 0 520 120"><path d="M30 100 C120 -10 400 -10 490 100" stroke={C.warn} strokeWidth="7" fill="none" strokeDasharray="16 12" strokeDashoffset={-frame * 2} strokeLinecap="round" /><path d="M468 84 L492 104 L462 112" stroke={C.warn} strokeWidth="7" fill="none" strokeLinecap="round" /></svg>
          <Chip text="bypass system" mono size={42} color={C.warn} />
        </div></Card></div>
      </In>
      <In t={T(ev(18, 0.45) - LEAD)} out={out1} s={0.3} cfg={theme.spring.bouncy} style={{ left: 880, top: 440 }}><Eq /></In>
      <In t={T(ev(18, 0.5) - LEAD)} out={out1} x={100} style={{ left: 1090, top: 300 }}>
        <Card w={720} h={470} glow="hero"><div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 36, paddingTop: 34 }}>
          <div style={{ position: "relative" }}><Server w={230} h={290} color={C.hero} led={C.hero} units={4} blink={frame} /><div style={{ position: "absolute", right: -40, top: -30 }}><Padlock size={96} /></div></div>
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}><Ico d={D.code} size={110} color={C.accent} /><Chip text="IT খাত" size={50} color={C.accent} /></div>
        </div></Card>
      </In>
      {/* cue 19: databases that do not talk to each other */}
      {dbN.map((n, i) => (
        <In key={i} t={T(ev(19, 0.04 + i * 0.12) - LEAD)} out={out2 - i * 2} y={50} style={{ left: 150 + i * 430, top: 300 }}><Db w={220} h={264} color={i % 2 ? C.cool : C.accent} label={n} /></In>
      ))}
      {[0, 1, 2].map((i) => (
        <In key={i} t={T(ev(19, 0.4 + i * 0.1))} out={out2} s={0.3} style={{ left: 375 + i * 430, top: 380 }}>
          <svg width="210" height="80" viewBox="0 0 240 80"><path d="M10 40 H88 M152 40 H230" stroke={C.dim} strokeWidth="6" strokeDasharray="10 9" strokeLinecap="round" /><path d="M100 22 L140 58 M140 22 L100 58" stroke={C.hero} strokeWidth="8" strokeLinecap="round" /></svg>
        </In>
      ))}
      <In t={T(ev(19, 0.45))} out={out2} y={30} style={{ left: 700, top: 735 }}><Chip text="connected না!" size={56} color={C.hero} /></In>
      {/* cue 20: where did the thousands of crores go? */}
      {[0, 1, 2, 3, 4, 5].map((i) => {
        const prog = ip(T(ev(20, 0.15) + i * 9), 0, 44, 0, 1, theme.ease.inOut);
        const x = 440 + prog * 1010, y = 560 - Math.sin(prog * Math.PI) * 190 + (i % 3) * 26;
        return <div key={i} style={{ position: "absolute", left: x, top: y, opacity: ip(T(ev(20, 0.15) + i * 9), 0, 6, 0, 1) * (1 - ip(prog, 0.92, 1, 0, 1)), transform: `rotate(${prog * 40 - 20}deg)` }}><Note w={190} /></div>;
      })}
      <In t={T(ev(20, 0.0) - LEAD)} y={30} style={{ left: 130, top: 330 }}><Card w={380} h={300} glow="acc"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, paddingTop: 36 }}><Ico d={D.cloud} size={96} color={C.accent} /><Tx size={46}>IT project</Tx><Chip text="হাজার হাজার কোটি" size={32} color={C.warn} /></div></Card></In>
      {[0, 1, 2].map((i) => (
        <In key={i} t={T(ev(20, 0.4 + i * 0.1))} x={60} style={{ left: 1500, top: 300 + i * 175 }}>
          <Card w={330} h={150}><div style={{ display: "flex", alignItems: "center", gap: 18, padding: "0 26px", height: "100%" }}><Ico d={D.user} size={74} color={C.hero} /><Tx size={50} color={C.hero}>পকেট ?</Tx></div></Card>
        </In>
      ))}
    </>
  );
};
