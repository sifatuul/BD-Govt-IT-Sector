import React from "react";
import { theme, bn } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Tx, Chip } from "../components/ui";

const C = theme.colors;
const NODES = [[420, 400], [1500, 400], [960, 764]];
export const S13: React.FC = () => {
  const { T, frame } = useSc();
  const line = ip(T(ev(42, 0.5)), 0, 24, 0, 1);
  return (
    <>
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080}>
        {NODES.map(([x, y], i) => <line key={i} x1="960" y1="525" x2={960 + (x - 960) * line} y2={525 + (y - 525) * line} stroke={C.accent} strokeWidth="5" strokeDasharray="14 10" strokeDashoffset={-frame * 2} opacity={0.7} />)}
        {[0, 1, 2].map((i) => <circle key={i} cx="960" cy="525" r={170 + i * 56 + Math.sin(frame / 10 + i) * 6} fill="none" stroke={C.accent} strokeWidth="2" opacity={0.25 - i * 0.06} />)}
      </svg>
      <In t={T(ev(42, 0) - LEAD)} s={0.5} cfg={theme.spring.bouncy} style={{ left: 760, top: 400 }}>
        <div style={{ width: 400, height: 250, borderRadius: 36, background: `linear-gradient(150deg, ${C.accentDim}, ${C.panel})`, border: `3px solid ${C.accent}`, boxShadow: `0 0 70px ${C.glowAcc}`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
          <Tx size={72} mono>IT</Tx><Tx size={56}>sector</Tx>
        </div>
      </In>
      {NODES.map(([x, y], i) => (
        <In key={i} t={T(ev(42, 0.55 + i * 0.12))} s={0.3} cfg={theme.spring.bouncy} style={{ left: x - 100, top: y - 100 }}>
          <div style={{ width: 200, height: 200, borderRadius: "50%", background: C.panel2, border: `4px solid ${[C.hero, C.warn, C.accent][i]}`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", boxShadow: `0 0 40px ${[C.glowHero, "rgba(255,200,87,0.3)", C.glowAcc][i]}` }}>
            <Tx size={90} color={[C.hero, C.warn, C.accent][i]}>{bn(i + 1)}</Tx><Tx size={64} color={C.text} style={{ marginTop: -14 }}>?</Tx>
          </div>
        </In>
      ))}
      <In t={T(ev(42, 0.7))} y={20} style={{ left: 750, top: 262 }}><Chip text="focus কোথায়?" size={46} color={C.warn} /></In>
    </>
  );
};
