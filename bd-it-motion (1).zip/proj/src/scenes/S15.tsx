import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Ico, D } from "../graphics/g";

const C = theme.colors;
const NODES: [string, number][] = [["NID", 0.4], ["জন্ম নিবন্ধন", 0.55], ["passport", 0.7], ["bank", 0.82], ["tax", 0.92]];
const POS = [-90, -20, 40, 140, 200].map((a) => [960 + Math.cos((a * Math.PI) / 180) * 650, 560 + Math.sin((a * Math.PI) / 180) * 245]);
export const S15: React.FC = () => {
  const { T, frame } = useSc();
  const o1 = T(ev(48, 0.33));
  const fix = T(ev(49, 0.6));
  const pulse = (i: number) => ip(T(ev(50, 0.0) + i * 4), 0, 30, 0, 1, theme.ease.inOut);
  return (
    <>
      {/* 47-48: kinetic title */}
      <In t={T(ev(47, 0) - LEAD)} out={o1} s={0.6} cfg={theme.spring.bouncy} style={{ left: 260, top: 320, width: 1400 }}><Tx size={230} color={C.accent} style={{ lineHeight: 1 }}>One API,</Tx></In>
      <In t={T(ev(48, 0) - 2)} out={o1} s={0.6} cfg={theme.spring.bouncy} style={{ left: 260, top: 560, width: 1400 }}><Tx size={230} style={{ lineHeight: 1 }}>One Nation</Tx></In>
      <In t={T(ev(48, 0.1))} out={o1} y={0} style={{ left: 460, top: 830, width: 1000 }}><div style={{ display: "flex", height: 14, borderRadius: 7, overflow: "hidden" }}><div style={{ flex: 3, background: C.accent }} /><div style={{ flex: 1, background: C.hero }} /></div></In>
      {/* hub and spoke: every database linked */}
      <svg style={{ position: "absolute", left: 0, top: 0 }} width={1920} height={1080}>
        {POS.map(([x, y], i) => { const t = T(ev(48, NODES[i][1])); const l = ip(t, 0, 16, 0, 1); return (
          <g key={i}><line x1="960" y1="560" x2={960 + (x - 960) * l} y2={560 + (y - 560) * l} stroke={C.accent} strokeWidth="5" opacity="0.8" />
            {pulse(i) > 0 && pulse(i) < 1 && <circle cx={960 + (x - 960) * pulse(i)} cy={560 + (y - 560) * pulse(i)} r="16" fill={C.warn} />}</g>
        ); })}
      </svg>
      <In t={T(ev(48, 0.36) - LEAD)} s={0.4} cfg={theme.spring.bouncy} style={{ left: 840, top: 440 }}>
        <div style={{ width: 240, height: 240, borderRadius: "50%", background: `radial-gradient(circle, ${C.accent}, ${C.accentDim})`, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 ${50 + Math.sin(frame / 8) * 15}px ${C.glowAcc}` }}><Tx size={90} mono color={C.bg}>API</Tx></div>
      </In>
      {NODES.map(([n, f], i) => (
        <In key={i} t={T(ev(48, f))} s={0.5} cfg={theme.spring.bouncy} style={{ left: POS[i][0] - 160, top: POS[i][1] - 50 }}>
          <div style={{ position: "relative" }}><Card w={320} h={100} border={pulse(i) >= 1 ? C.accent : undefined} glow={pulse(i) >= 1 ? "acc" : null}><div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%" }}><Tx size={n.length > 6 ? 40 : 50}>{n}</Tx></div></Card>
            {pulse(i) >= 1 && <div style={{ position: "absolute", right: -18, top: -18, width: 52, height: 52, borderRadius: "50%", background: C.accent, display: "flex", alignItems: "center", justifyContent: "center" }}><Ico d={D.check} size={34} color={C.bg} sw={6} /></div>}
          </div>
        </In>
      ))}
      <In t={fix} y={30} style={{ left: 700, top: 715 }}><Chip text="বানান ঠিক, একবার" size={42} color={C.warn} /></In>
      <In t={T(ev(50, 0.0))} y={-20} style={{ left: 1130, top: 255 }}><Chip text="automatic update" mono size={34} color={C.accent} /></In>
    </>
  );
};
