import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx, heavy } from "../components/ui";
import { Db, Gauge, Ico, D, NidCard, Note, Server, Stamp } from "../graphics/g";

const C = theme.colors;
const Mini: React.FC<{ title: string; color: string; w?: number }> = ({ title, color, w = 330 }) => (
  <div style={{ width: w, height: w * 0.62, borderRadius: 20, background: `linear-gradient(140deg, ${color}, ${color}77)`, border: "2px solid rgba(255,255,255,0.3)", boxShadow: `0 20px 40px -14px ${C.shadow}`, position: "relative" }}>
    <div style={{ position: "absolute", left: 20, top: 16, fontFamily: theme.fonts.sans, fontSize: w * 0.12, fontWeight: 700, color: C.bg, ...heavy(w * 0.12) }}>{title}</div>
    <div style={{ position: "absolute", left: 20, bottom: 18, width: w * 0.5, height: 12, borderRadius: 6, background: "rgba(7,19,15,0.4)" }} />
    <div style={{ position: "absolute", right: 20, bottom: 18, width: w * 0.18, height: w * 0.18, borderRadius: "50%", background: "rgba(7,19,15,0.3)" }} />
  </div>
);

export const S12: React.FC = () => {
  const { T, frame } = useSc();
  const o1 = T(ev(37, 0)), o2 = T(ev(38, 0)), o3 = T(ev(40, 0)), o4 = T(ev(41, 0));
  const load = ip(T(ev(37, 0.08)), 0, 36, 0.12, 1, theme.ease.in);
  const down = T(ev(37, 0.45));
  const names = [["জন্ম নিবন্ধন", C.accent], ["NID", C.cool], ["passport", C.warn]];
  const flurry = [C.accent, C.warn, C.cool, C.hero, "#B388FF", "#FF8A65", C.accent, C.warn];
  return (
    <>
      {/* 36: three servers, no connection */}
      {names.map(([n, c], i) => (
        <In key={i} t={T(ev(36, 0.04 + i * 0.1) - LEAD)} out={o1 - i * 2} y={50} style={{ left: 220 + i * 560, top: 290 }}>
          <div style={{ width: 300, display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}><Server w={260} h={340} color={c as string} led={c as string} blink={frame + i * 7} /><Tx size={52}>{n as string}</Tx></div>
        </In>
      ))}
      {[0, 1].map((i) => (
        <In key={i} t={T(ev(36, 0.5 + i * 0.12))} out={o1} s={0.3} style={{ left: 505 + i * 560, top: 400 }}>
          <svg width="270" height="90" viewBox="0 0 240 80"><path d="M10 40 H88 M152 40 H230" stroke={C.dim} strokeWidth="6" strokeDasharray="10 9" strokeLinecap="round" /><path d="M100 22 L140 58 M140 22 L100 58" stroke={C.hero} strokeWidth="8" strokeLinecap="round" /></svg>
        </In>
      ))}
      <In t={T(ev(36, 0.55))} out={o1} y={30} style={{ left: 640, top: 770 }}><Chip text="কোনো connection নেই" size={46} color={C.hero} /></In>
      {/* 37: a little load and the birth-registration server goes down */}
      <In t={T(ev(37, 0) - LEAD)} out={o2} x={-90} style={{ left: 250, top: 290 }}>
        <div style={{ width: 340, display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
          <Server w={300} h={400} color={down > 0 ? C.hero : C.accent} led={down > 0 ? C.hero : C.accent} blink={down > 0 ? 0 : frame} />
          <Tx size={50}>জন্ম নিবন্ধন</Tx>
        </div>
      </In>
      <In t={T(ev(37, 0.05) - LEAD)} out={o2} x={90} style={{ left: 760, top: 300 }}>
        <Card w={600} h={400}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 30 }}><Gauge size={420} p={down > 0 ? 1 : load} label="load" /></div></Card>
      </In>
      {[0, 1, 2, 3].map((i) => { const p = ip(T(ev(37, 0.05) + i * 8), 0, 36, 0, 1, theme.ease.inOut); return <div key={i} style={{ position: "absolute", left: 1760 - p * 340, top: 320 + i * 110, opacity: (1 - p * 0.3) * ip(T(ev(37, 0.05) + i * 8), 0, 6, 0, 1) * (down > 0 ? 0.3 : 1) * (o2 > 0 ? ip(o2, 0, 9, 1, 0) : 1) }}><Ico d={D.user} size={80} color={C.cool} /></div>; })}
      {down > -2 && <div style={{ position: "absolute", left: 1330, top: 540, opacity: ip(down, 0, 3, 0, 1) * (o2 > 0 ? ip(o2, 0, 9, 1, 0) : 1), transform: `scale(${ip(down, 0, 8, 2.6, 1)})` }}><Stamp text="DOWN" size={110} /></div>}
      {/* 38-39: card flood */}
      {[["family card", C.accent, 150, 420], ["citizen card", C.cool, 640, 480], ["স্বাস্থ্য কার্ড", C.warn, 1130, 420]].map(([n, c, x, y], i) => (
        <In key={i} t={T(ev(39, i * 0.2) - LEAD)} out={o3} y={-70} rot={(i - 1) * 8} cfg={theme.spring.bouncy} style={{ left: x as number, top: y as number }}><Mini title={n as string} color={c as string} w={440} /></In>
      ))}
      {flurry.map((c, i) => (
        <In key={i} t={T(ev(38, 0.25) + i * 6)} out={o3} y={-120} rot={(i % 3) * 14 - 14} fade={0.55} style={{ left: 110 + (i % 4) * 430 + (i % 2) * 70, top: 300 + Math.floor(i / 4) * 330 }}><Mini title="কার্ড" color={c} w={250} /></In>
      ))}
      {/* 40: one smart NID should serve everything */}
      <In t={T(ev(40, 0) - LEAD)} out={o4} s={0.6} cfg={theme.spring.bouncy} style={{ left: 560, top: 360 }}><NidCard w={800} h={440} /></In>
      {[D.shield, D.doc, D.cap, D.cloud, D.phone, D.user].map((d, i) => {
        const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
        return (
          <In key={i} t={T(ev(40, 0.2 + i * 0.06))} out={o4} s={0.3} cfg={theme.spring.bouncy} style={{ left: 960 + Math.cos(a) * 760 - 45, top: 580 + Math.sin(a) * 250 - 45 }}><div style={{ width: 90, height: 90, borderRadius: "50%", background: C.panel2, border: `3px solid ${C.accent}`, display: "flex", alignItems: "center", justifyContent: "center" }}><Ico d={d} size={50} color={C.accent} /></div></In>
        );
      })}
      {/* 41: waste + duplication */}
      <In t={T(ev(41, 0) - LEAD)} x={-80} style={{ left: 140, top: 300 }}>
        <Card w={780} h={530} border={C.hero}><div style={{ padding: "26px 40px" }}>
          <Chip text="নতুন কার্ড print" size={44} color={C.warn} />
          <div style={{ position: "relative", marginTop: 30, height: 230 }}>
            {[0, 1, 2].map((i) => <div key={i} style={{ position: "absolute", left: 40 + i * 60, top: i * 14, opacity: ip(T(ev(41, 0.1 + i * 0.1)), 0, 10, 0, 1) }}><Mini title="কার্ড" color={[C.accent, C.cool, C.warn][i]} w={300} /></div>)}
            {[0, 1, 2, 3].map((i) => { const p = ip(T(ev(41, 0.3) + i * 7), 0, 40, 0, 1); return <div key={i} style={{ position: "absolute", left: 420 + (i % 2) * 150, top: 120 - p * 140, opacity: 1 - p, transform: `rotate(${p * 25}deg)` }}><Note w={150} /></div>; })}
          </div>
          <Tx size={64} color={C.hero} style={{ marginTop: 20 }}>অর্থের অপচয়</Tx>
        </div></Card>
      </In>
      <In t={T(ev(41, 0.6) - LEAD)} x={80} style={{ left: 980, top: 300 }}>
        <Card w={780} h={530} border={C.warn}><div style={{ padding: "30px 40px" }}>
          <Chip text="data duplication" mono size={40} color={C.warn} />
          <div style={{ position: "relative", height: 280, marginTop: 30 }}>
            {[0, 1, 2].map((i) => <div key={i} style={{ position: "absolute", left: 90 + i * 190, top: i === 1 ? 40 : 0, opacity: ip(T(ev(41, 0.65 + i * 0.1)), 0, 10, 0, 1) }}><Db w={150} h={180} color={C.warn} /></div>)}
          </div>
          <Tx size={52} style={{ marginTop: 10 }}>একই data, বারবার</Tx>
        </div></Card>
      </In>
    </>
  );
};
