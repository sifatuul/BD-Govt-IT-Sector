import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Brick, Ico, D, Note } from "../graphics/g";

const C = theme.colors;
const Fiber: React.FC = () => { const { frame } = useSc(); return (
  <svg width="260" height="110" viewBox="0 0 260 110"><path d="M10 80 C70 80 70 30 130 30 C190 30 190 80 250 80" stroke={C.accent} strokeWidth="6" fill="none" strokeLinecap="round" /><circle cx={10 + 240 * ((frame * 0.022) % 1)} cy={80 - 50 * Math.sin(Math.PI * ((frame * 0.022) % 1))} r="8" fill={C.text} /><circle cx={10 + ((frame * 5) % 240)} cy="102" r="5" fill={C.accent} opacity="0.7" /></svg>
); };
const NoSign: React.FC<{ size: number }> = ({ size }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: `drop-shadow(0 0 24px ${C.glowHero})` }}><circle cx="50" cy="50" r="42" fill="rgba(244,42,65,0.12)" stroke={C.hero} strokeWidth="9" /><path d="M20 80 L80 20" stroke={C.hero} strokeWidth="9" strokeLinecap="round" /></svg>
);

export const S14: React.FC = () => {
  const { T } = useSc();
  const o1 = T(ev(45, 0)), o2 = T(ev(46, 0));
  const build = ip(T(ev(44, 0.0)), 0, 40, 0, 1);
  const flow = (i: number, a: number, b: number) => ip(T(ev(45, 0.2) + i * 12), 0, 30, a, b, theme.ease.inOut);
  const tc = (k: number) => T(ev(46, k) - LEAD);
  return (
    <>
      {/* 44: stop building brick-and-stone */}
      <div style={{ position: "absolute", left: 460, top: 300, width: 1000, opacity: o1 > 0 ? ip(o1, 0, 9, 1, 0, theme.ease.in) : 1 }}>
        {[0, 1, 2, 3, 4].map((r) => (
          <div key={r} style={{ display: "flex", gap: 6, marginBottom: 6, marginLeft: r % 2 ? 50 : 0 }}>
            {Array.from({ length: r % 2 ? 9 : 10 }).map((_, k) => <div key={k} style={{ opacity: ip(build, (r * 10 + k) / 55, (r * 10 + k) / 55 + 0.15, 0, 1) * (T(ev(44, 0.38)) > 0 ? 0.45 : 1), transform: `translateY(${(1 - ip(build, (r * 10 + k) / 55, (r * 10 + k) / 55 + 0.15, 0, 1)) * -30}px)` }}><Brick w={94} h={54} /></div>)}
          </div>
        ))}
      </div>
      <In t={T(ev(44, 0.38))} out={o1} s={2.4} cfg={theme.spring.bouncy} style={{ left: 710, top: 320 }}><NoSign size={500} /></In>
      {/* 45: the budget must not go into contractors' pockets */}
      <In t={T(ev(45, 0) - LEAD)} out={o2} x={-100} style={{ left: 130, top: 330 }}><Card w={560} h={400} glow="acc"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20, paddingTop: 40 }}><Ico d={D.cloud} size={110} color={C.accent} /><Tx size={64}>IT বাজেট</Tx><Chip text="IT খাত" size={36} color={C.accent} /></div></Card></In>
      <In t={T(ev(45, 0) - LEAD)} out={o2} x={100} style={{ left: 1230, top: 330 }}><Card w={560} h={400} border={C.hero}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20, paddingTop: 40 }}><div style={{ opacity: 0.55 }}><Ico d={D.user} size={110} color={C.hero} /></div><Tx size={58}>ঠিকাদারদের পকেট</Tx></div><div style={{ position: "absolute", right: 24, top: 20 }}><Ico d={D.cross} size={80} color={C.hero} sw={6} /></div></Card></In>
      {[0, 1, 2].map((i) => { const p = flow(i, 0, 1); return <div key={i} style={{ position: "absolute", left: 720 + p * 330, top: 450 + (i - 1) * 40, opacity: ip(p, 0, 0.1, 0, 1) * (1 - ip(p, 0.7, 0.95, 0, 1)), transform: `rotate(${p * 20}deg)` }}><Note w={170} /></div>; })}
      <In t={T(ev(45, 0.6))} out={o2} y={20} style={{ left: 690, top: 640 }}><Chip text="যাওয়া যাবে না" size={48} color={C.hero} /></In>
      {/* 46: invest in the real foundations */}
      {[["cloud server", D.cloud, 130], ["cyber security", D.shield, 700], ["optical fiber", D.fiber, 1270]].map(([n, d, x], i) => (
        <In key={i} t={tc([0.0, 0.0, 0.6][i] + (i === 1 ? 0.15 : 0))} y={60} style={{ left: x as number, top: 320 }}>
          <Card w={520} h={440} glow="acc" border={C.accent}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 22, paddingTop: 44 }}>
            {i === 2 ? <Fiber /> : <Ico d={d as string} size={150} color={C.accent} sw={3} />}
            <Tx size={56} mono>{n as string}</Tx>
            <Chip text="invest" mono size={40} color={C.warn} />
          </div></Card>
        </In>
      ))}
    </>
  );
};
