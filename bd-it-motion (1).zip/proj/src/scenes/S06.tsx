import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Cert, Ico, D, Note } from "../graphics/g";

const C = theme.colors;
const Person: React.FC<{ label: string; color: string }> = ({ label, color }) => (
  <div style={{ width: 340, display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
    <div style={{ width: 230, height: 230, borderRadius: "50%", background: C.panel2, border: `5px solid ${color}`, display: "flex", alignItems: "center", justifyContent: "center" }}><Ico d={D.user} size={150} color={color} /></div>
    <Tx size={48}>{label}</Tx>
  </div>
);

export const S06: React.FC = () => {
  const { T, frame } = useSc();
  const tNotes = T(ev(15, 0.9)); // notes slide under the table
  const tCert = T(ev(16, 0.74));
  return (
    <>
      <In t={T(ev(15, 0) - LEAD)} x={-80} style={{ left: 150, top: 275 }}><Person label="আমি" color={C.accent} /></In>
      <In t={T(ev(15, 0) - LEAD - 4)} x={80} style={{ left: 1430, top: 275 }}><Person label="ইউনিয়ন পরিষদ" color={C.hero} /></In>
      {/* whisper bubble */}
      <In t={T(ev(15, 0.12))} out={T(ev(16, 0.7))} s={0.4} cfg={theme.spring.bouncy} style={{ left: 640, top: 280 }}><Card w={430} h={120} style={{ borderRadius: 60 }}><div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100%" }}><Tx size={52} color={C.warn}>গোপনে…</Tx></div></Card></In>
      {/* the table */}
      <In t={T(ev(15, 0) - LEAD - 2)} y={40} style={{ left: 210, top: 590 }}>
        <div style={{ width: 1500, height: 44, borderRadius: 12, background: `linear-gradient(180deg, #8B5E3C, #5C3D26)`, boxShadow: `0 20px 30px -10px ${C.shadow}` }} />
        <div style={{ position: "absolute", left: 60, top: 40, width: 40, height: 240, background: "#4A301E" }} />
        <div style={{ position: "absolute", left: 1400, top: 40, width: 40, height: 240, background: "#4A301E" }} />
      </In>
      {/* raw notes appear, then slip under the table (drawn above the legs, below table top) */}
      {[0, 1, 2].map((i) => {
        const ta = T(ev(15, 0.5 + i * 0.07)); // appear fan above
        const slide = ip(tNotes - i * 5, 0, 34, 0, 1, theme.ease.inOut);
        const x = 420 + i * 40 + slide * 700, y = 330 + slide * 350 + i * 12;
        const o = ip(ta, 0, 10, 0, 1);
        return <div key={i} style={{ position: "absolute", left: x, top: y + 20, opacity: o, transform: `rotate(${(1 - slide) * (i - 1) * 8}deg) scale(${1 - slide * 0.12})`, zIndex: 5 }}><Note w={250} /></div>;
      })}
      <In t={T(ev(15, 0.5))} s={0.4} y={0} style={{ left: 440, top: 255 }}><Chip text="কাঁচা নোট" size={40} color={C.accent} /></In>
      {/* fresh online-updated certificate pops out */}
      <In t={tCert} y={40} s={0.5} cfg={theme.spring.bouncy} style={{ left: 740, top: 270 }}>
        <div style={{ filter: `drop-shadow(0 0 40px ${C.glowAcc})` }}><Cert w={440} h={290} title="জন্ম নিবন্ধন" sub="online updated" /></div>
      </In>
      <In t={tCert + 8} s={0.3} cfg={theme.spring.bouncy} style={{ left: 1170, top: 262 }}><Chip text="fresh" mono size={40} color={C.accent} /></In>
      <In t={T(ev(17, 0.45))} s={0.3} cfg={theme.spring.bouncy} style={{ left: 1700, top: 330 }}><Tx size={190} color={C.warn}>?</Tx></In>
    </>
  );
};
