import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Brick, Building, Ico, D, NidCard, Note } from "../graphics/g";

const C = theme.colors;
const Flag: React.FC<{ w: number }> = ({ w }) => (
  <div style={{ width: w, height: w * 0.6, background: "#0B6B4A", borderRadius: 16, position: "relative", boxShadow: `0 0 60px ${C.glowAcc}` }}><div style={{ position: "absolute", left: w * 0.4 - w * 0.17, top: w * 0.3 - w * 0.17, width: w * 0.34, height: w * 0.34, borderRadius: "50%", background: C.hero }} /></div>
);
export const S17: React.FC = () => {
  const { T, frame } = useSc();
  const o1 = T(ev(57, 0)), o2 = T(ev(58, 0.02)), o3 = T(ev(58, 0.74));
  const draw = ip(T(ev(58, 0.12)), 0, 60, 0, 1, theme.ease.soft);
  const go = T(ev(59, 0) - 2);
  const noteX = ip(T(ev(56, 0.62)), 0, 22, 0, 1, theme.ease.inOut);
  const ring = (i: number) => ip(go - i * 8, 0, 40, 0, 1);
  return (
    <>
      {/* 56: the dream, then the 100-taka bribe */}
      <In t={T(ev(56, 0) - LEAD)} out={o1} x={-90} style={{ left: 240, top: 330 }}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20 }}><Flag w={560} /><Chip text="ডিজিটাল বাংলাদেশের স্বপ্ন" size={44} color={C.accent} /></div></In>
      <div style={{ position: "absolute", left: 1100 - (1 - noteX) * 700, top: 400, opacity: noteX > 0 ? 1 : 0, transform: `rotate(${(1 - noteX) * 14}deg)`, ...(o1 > 0 ? { opacity: ip(o1, 0, 9, 1, 0) } : {}) }}><Note w={520} /></div>
      <In t={T(ev(56, 0.7))} out={o1} s={0.4} cfg={theme.spring.bouncy} style={{ left: 1180, top: 700 }}><Chip text="ঘুষ" size={64} color={C.hero} /></In>
      {/* 57: cards and concrete cannot fix it */}
      <In t={T(ev(57, 0) - LEAD)} out={o2} x={-90} style={{ left: 150, top: 330 }}><NidCard w={620} h={390} /></In>
      <In t={T(ev(57, 0.2) - LEAD)} out={o2} x={90} style={{ left: 1100, top: 260 }}><Building w={300} floors={6} color={C.hero} /></In>
      <In t={T(ev(57, 0.55))} out={o2} s={2.2} cfg={theme.spring.bouncy} style={{ left: 640, top: 330 }}><svg width="640" height="420" viewBox="0 0 100 70"><path d="M12 8 L88 62 M88 8 L12 62" stroke={C.hero} strokeWidth="7" strokeLinecap="round" /></svg></In>
      {/* 58: rebuild the architecture */}
      <svg style={{ position: "absolute", left: 0, top: 0, opacity: ip(T(ev(58, 0.02)), 0, 10, 0, 1) * (o3 > 0 ? ip(o3, 0, 9, 1, 0) : 1) }} width={1920} height={1080}>
        {[["database layer", 650], ["One API", 500], ["cloud + security", 350]].map(([n, y], i) => { const l = Math.min(1, Math.max(0, draw * 3 - i)); return (
          <g key={i}><rect x={320} y={y as number} width={1280 * l} height="110" rx="20" fill="rgba(46,204,143,0.10)" stroke={C.accent} strokeWidth="4" strokeDasharray="14 8" />
            {l > 0.8 && <text x="960" y={(y as number) + 72} textAnchor="middle" fontSize="54" fontWeight="700" fill={C.text} fontFamily="VM">{n as string}</text>}</g>
        ); })}
      </svg>
      <In t={T(ev(58, 0.3))} out={o3} y={20} style={{ left: 620, top: 255 }}><Chip text="system-এর architecture" mono size={42} color={C.warn} /></In>
      {/* 58-59: start right now */}
      <In t={T(ev(58, 0.74) - LEAD)} s={0.3} cfg={theme.spring.bouncy} style={{ left: 760, top: 330 }}>
        <div style={{ width: 400, height: 400, position: "relative" }}>
          {[0, 1, 2].map((i) => <div key={i} style={{ position: "absolute", inset: 0, borderRadius: "50%", border: `5px solid ${C.hero}`, opacity: ring(i) > 0 ? (1 - ring(i)) * 0.8 : 0, transform: `scale(${1 + ring(i) * 1.5})` }} />)}
          <div style={{ position: "absolute", inset: 30, borderRadius: "50%", background: `radial-gradient(circle, ${C.hero}, ${C.heroDim})`, boxShadow: `0 0 ${60 + Math.sin(frame / 5) * 20}px ${C.glowHero}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="170" height="170" viewBox="0 0 48 48"><path d="M16 10 L38 24 L16 38 Z" fill={C.text} /></svg>
          </div>
        </div>
      </In>
      <In t={T(ev(59, 0) - 2)} s={0.4} cfg={theme.spring.bouncy} style={{ left: 1200, top: 430 }}><Tx size={150} color={C.accent}>এখনই</Tx></In>
    </>
  );
};
