import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { BigNum, Brick, Building, Ico, D } from "../graphics/g";

const C = theme.colors;
const Wifi: React.FC = () => (
  <svg width="120" height="120" viewBox="0 0 48 48"><path d="M5 18 a27 27 0 0 1 38 0 M11 25 a18 18 0 0 1 26 0 M17 32 a9 9 0 0 1 14 0" stroke={C.accent} strokeWidth="4" fill="none" strokeLinecap="round" /><circle cx="24" cy="38" r="2.6" fill={C.accent} /></svg>
);

export const S09: React.FC = () => {
  const { T, frame } = useSc();
  const oA = T(ev(26, 0)), oB = T(ev(27, 0.12)), oC = T(ev(28, 0.46)), oD = T(ev(29, 0));
  const count = ip(T(ev(25, 0.62)), 0, 44, 0, 1370);
  const floors = ip(T(ev(26, 0.08)), 0, 96, 0, 6, theme.ease.soft);
  const bricks = ip(T(ev(28, 0.0)), 0, 40, 0, 1);
  const bar = ip(T(ev(28, 0.5)), 0, 26, 0, 1);
  return (
    <>
      {/* A: the centre + the amount */}
      <In t={T(ev(25, 0) - LEAD)} out={oA} x={-90} style={{ left: 150, top: 290 }}>
        <Card w={700} h={480} glow="acc"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20, paddingTop: 36 }}>
          <Building w={220} floors={3} /> 
          <Tx size={50}>জেলা পর্যায়ের</Tx><Chip text="IT training & incubation center" mono size={30} color={C.accent} />
        </div></Card>
      </In>
      <In t={T(ev(25, 0.62) - LEAD)} out={oA} x={90} style={{ left: 900, top: 310 }}>
        <Card w={860} h={400} glow="hero"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", gap: 12 }}>
          <Tx size={44} color={C.dim}>খরচ প্রায়</Tx><BigNum v={count} size={170} color={C.hero} /><Tx size={62}>কোটি টাকা</Tx>
        </div></Card>
      </In>
      {/* B: concrete tower rising on farmland */}
      <In t={T(ev(26, 0) - LEAD)} out={oB} y={40} style={{ left: 0, top: 0, width: 1920, height: 1080 }}>
        <div style={{ position: "absolute", left: 120, top: 700, width: 1680, height: 150, borderRadius: 20, background: `linear-gradient(180deg, #3F7A3A, #28522A)` }}>
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((i) => <div key={i} style={{ position: "absolute", left: 20 + i * 140, top: 20, width: 90, height: 8, background: "rgba(255,255,255,0.18)", borderRadius: 4 }} />)}
        </div>
        <div style={{ position: "absolute", left: 800, top: 270 }}><Building w={330} floors={6} shown={floors} color={C.hero} /></div>
      </In>
      <In t={T(ev(26, 0.02))} out={oB} x={-60} style={{ left: 200, top: 400 }}><Card w={460} h={190}><div style={{ display: "flex", alignItems: "center", gap: 22, padding: "0 34px", height: "100%" }}><Ico d="M24 42 V18 M24 28 C16 28 12 22 12 14 C20 14 24 20 24 28 M24 24 C32 24 36 18 36 10 C28 10 24 16 24 24" size={80} color={C.accent} /><Tx size={56}>কৃষিজমি</Tx></div></Card></In>
      <In t={T(ev(26, 0.55))} out={oB} x={60} style={{ left: 1300, top: 400 }}><Card w={460} h={190} glow="hero"><div style={{ display: "flex", alignItems: "center", gap: 22, padding: "0 34px", height: "100%" }}><Tx size={96} color={C.hero}>৬</Tx><Tx size={56}>তলা ভবন</Tx></div></Card></In>
      {/* C: what was needed vs what was bought */}
      <In t={T(ev(27, 0.12) - LEAD)} out={oC} x={-100} style={{ left: 130, top: 300 }}>
        <Card w={800} h={480} border={C.accent}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 18, paddingTop: 30 }}>
          <Chip text="দরকার ছিল" size={44} color={C.accent} />
          <div style={{ display: "flex", gap: 60, alignItems: "center" }}><Wifi /><Ico d={D.user} size={120} color={C.accent} /></div>
          <Tx size={56}>high-speed internet</Tx><Tx size={56}>আর trainer</Tx>
        </div></Card>
      </In>
      <In t={T(ev(28, 0.0) - LEAD)} out={oC} x={100} style={{ left: 990, top: 300 }}>
        <Card w={800} h={480} border={C.hero} glow="hero"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 18, paddingTop: 30 }}>
          <Chip text="খরচ হলো" size={44} color={C.hero} />
          <div style={{ display: "flex", gap: 10, alignItems: "flex-end", height: 150 }}>
            {[0, 1, 2, 3, 4].map((i) => <div key={i} style={{ display: "flex", flexDirection: "column", gap: 6, opacity: ip(bricks, i * 0.14, i * 0.14 + 0.3, 0, 1) }}>{[0, 1, 2].slice(0, 1 + (i % 3)).map((k) => <Brick key={k} w={110} h={42} />)}</div>)}
          </div>
          <Tx size={56}>ইট, বালু, সিমেন্ট</Tx>
        </div></Card>
      </In>
      {/* D: the contractor commission */}
      <In t={T(ev(28, 0.46) - LEAD)} out={oD} y={50} style={{ left: 260, top: 330 }}>
        <Card w={1400} h={440} glow="hero"><div style={{ padding: "44px 60px" }}>
          <Chip text="ঠিকাদারদের কমিশন" size={50} color={C.warn} />
          <div style={{ display: "flex", height: 110, marginTop: 50, borderRadius: 20, overflow: "hidden" }}>
            <div style={{ width: `${bar * 86}%`, background: C.hero, display: "flex", alignItems: "center", justifyContent: "center" }}><Tx size={46}>ভবন নির্মাণ</Tx></div>
            <div style={{ width: `${bar * 14}%`, background: C.accent }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 26 }}><Tx size={42} color={C.hero}>কমিশন বেশি</Tx><Tx size={38} color={C.accent}>internet / trainer</Tx></div>
        </div></Card>
      </In>
      {/* E: an empty building */}
      <In t={T(ev(29, 0) - LEAD)} y={50} style={{ left: 330, top: 285 }}><Building w={420} floors={6} empty color={C.hero} /></In>
      {[["freelancer নেই", 0.1, 380], ["IT ecosystem নেই", 0.4, 540]].map(([t, f, y], i) => (
        <In key={i} t={T(ev(29, f as number))} x={80} style={{ left: 940, top: y as number }}>
          <Card w={720} h={130} border={C.hero}><div style={{ display: "flex", alignItems: "center", gap: 26, padding: "0 34px", height: "100%" }}><Ico d={D.cross} size={70} color={C.hero} sw={6} /><Tx size={58}>{t as string}</Tx></div></Card>
        </In>
      ))}
    </>
  );
};
