import React from "react";
import { theme, bn } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc, useSp } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Ico, D } from "../graphics/g";

const C = theme.colors;
const Step: React.FC<{ n: number; title: string; sub: string; icon: string; on: number; color: string }> = ({ n, title, sub, icon, on, color }) => (
  <Card w={520} h={330} border={on > 0.5 ? color : undefined} glow={on > 0.5 ? (color === C.hero ? "hero" : "acc") : null}>
    <div style={{ position: "absolute", left: 26, top: 22, width: 70, height: 70, borderRadius: "50%", background: color, display: "flex", alignItems: "center", justifyContent: "center" }}><Tx size={46} color={C.bg}>{bn(n)}</Tx></div>
    <div style={{ position: "absolute", right: 30, top: 24 }}><Ico d={icon} size={86} color={color} /></div>
    <div style={{ position: "absolute", left: 30, right: 30, top: 130 }}><Tx size={52} align="left">{title}</Tx><Tx size={38} align="left" color={C.dim} style={{ marginTop: 8 }}>{sub}</Tx></div>
  </Card>
);

export const S05: React.FC = () => {
  const { T, frame } = useSc();
  const sp = useSp();
  const loop = ip(T(ev(14, 0) - LEAD), 0, 20, 0, 1);
  const hands = frame * 9;
  return (
    <>
      <In t={T(ev(13, 0) - LEAD)} x={-100} style={{ left: 100, top: 300 }}><Step n={1} title="মায়ের NID" sub="correction" icon={D.doc} on={sp(T(ev(13, 0.05)))} color={C.hero} /></In>
      <In t={T(ev(13, 0.5) - LEAD)} y={80} style={{ left: 700, top: 300 }}><Step n={2} title="বাবা-মায়ের" sub="জন্ম নিবন্ধন" icon={D.user} on={sp(T(ev(13, 0.6)))} color={C.warn} /></In>
      <In t={T(ev(13, 0.82) - LEAD)} x={100} style={{ left: 1300, top: 300 }}><Step n={3} title="আমারটা" sub="জন্ম নিবন্ধন" icon={D.cap} on={sp(T(ev(13, 0.9)))} color={C.accent} /></In>
      {[[640, 0.32], [1240, 0.7]].map(([x, f], i) => (
        <In key={i} t={T(ev(13, f) - LEAD)} s={0.4} x={-20} y={0} style={{ left: x - 10, top: 440 }}><Ico d={D.arrow} size={80} color={C.text} /></In>
      ))}
      <In t={T(ev(13, 0) - 2)} s={0.3} cfg={theme.spring.bouncy} style={{ left: 110, top: 700 }}><div style={{ transform: `rotate(${Math.sin(frame / 8) * 6}deg)` }}><Tx size={130} color={C.hero}>?</Tx></div></In>
      {/* the endless loop of hassle */}
      <svg style={{ position: "absolute", left: 0, top: 0, opacity: loop }} width={1920} height={1080}>
        <rect x="70" y="270" width="1780" height="400" rx="64" fill="none" stroke={C.hero} strokeWidth="6" strokeDasharray="22 16" strokeDashoffset={-frame * 3} opacity="0.9" />
      </svg>
      <In t={T(ev(14, 0.05) - LEAD)} s={0.4} cfg={theme.spring.bouncy} style={{ left: 760, top: 690 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 34 }}>
          <svg width="150" height="150" viewBox="0 0 100 100"><circle cx="50" cy="50" r="44" fill={C.panel} stroke={C.warn} strokeWidth="5" /><line x1="50" y1="50" x2="50" y2="20" stroke={C.text} strokeWidth="5" strokeLinecap="round" style={{ transformOrigin: "50px 50px", transform: `rotate(${hands}deg)` }} /><line x1="50" y1="50" x2="70" y2="50" stroke={C.warn} strokeWidth="5" strokeLinecap="round" style={{ transformOrigin: "50px 50px", transform: `rotate(${hands / 12}deg)` }} /></svg>
          <Chip text="হয়রানি" size={62} color={C.hero} />
        </div>
      </In>
    </>
  );
};
