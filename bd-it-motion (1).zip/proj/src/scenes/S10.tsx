import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Stamp } from "../graphics/g";

const C = theme.colors;
const COLS = [C.accent, C.cool, C.warn, C.hero, "#B388FF", "#FF8A65"];
export const S10: React.FC = () => {
  const { T, frame } = useSc();
  const N = 15;
  return (
    <>
      <In t={T(ev(30, 0) - LEAD)} y={40} style={{ left: 150, top: 280 }}>
        <Card w={900} h={560} glow="acc">
          <div style={{ position: "absolute", left: 30, top: 24, display: "flex", alignItems: "center", gap: 16 }}>
            <svg width="54" height="54" viewBox="0 0 48 48"><path d="M10 6 L40 24 L10 42 Z" fill={C.accent} /></svg><Tx size={40} mono align="left">play store</Tx>
          </div>
          {Array.from({ length: N }).map((_, i) => {
            const col = i % 5, row = Math.floor(i / 5);
            const tin = T(ev(30, 0.05) + i * 3);
            const gone = T(ev(31, 0.15) + ((i * 7) % N) * 4);
            const p = ip(tin, 0, 14, 0, 1);
            const g = ip(gone, 0, 12, 0, 1, theme.ease.in);
            return (
              <div key={i} style={{ position: "absolute", left: 48 + col * 168, top: 120 + row * 142, width: 128, height: 128, borderRadius: 30, background: `linear-gradient(140deg, ${COLS[i % 6]}, ${COLS[(i + 2) % 6]}88)`, opacity: p * (1 - g), transform: `scale(${(0.6 + 0.4 * p) * (1 - 0.5 * g)}) rotate(${g * 25}deg)`, boxShadow: `0 10px 24px -8px ${C.shadow}` }}>
                <div style={{ margin: 38, width: 52, height: 52, borderRadius: i % 2 ? "50%" : 12, background: "rgba(255,255,255,0.55)" }} />
              </div>
            );
          })}
        </Card>
      </In>
      <In t={T(ev(30, 0.0))} x={90} style={{ left: 1130, top: 300 }}><Chip text="শত শত mobile apps" size={46} color={C.accent} /></In>
      <In t={T(ev(30, 0.62) - LEAD)} x={90} style={{ left: 1130, top: 440 }}>
        <Card w={640} h={400} border={C.warn}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 18, paddingTop: 36 }}>
          <svg width="130" height="130" viewBox="0 0 48 48"><circle cx="24" cy="24" r="18" fill="none" stroke={C.warn} strokeWidth="4" /><path d="M16 32 L32 16" stroke={C.hero} strokeWidth="5" strokeLinecap="round" /><text x="24" y="31" textAnchor="middle" fontSize="20" fontWeight="700" fill={C.warn} fontFamily="Poppins">$</text></svg>
          <Tx size={50}>maintenance budget</Tx><Chip text="নেই" size={44} color={C.hero} />
        </div></Card>
      </In>
      <In t={T(ev(31, 0.5))} s={3} y={0} cfg={theme.spring.bouncy} style={{ left: 260, top: 450 }}>
        <div style={{ transform: `rotate(${Math.sin(frame / 4) * 1.5}deg)` }}><Stamp text="উধাও!" size={140} /></div>
      </In>
    </>
  );
};
