import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Cert, Ico, D, Gear, NidCard } from "../graphics/g";

const C = theme.colors;
const NotEq: React.FC = () => (
  <svg width="120" height="120" viewBox="0 0 48 48"><path d="M10 18 H38 M10 30 H38 M30 8 L18 40" stroke={C.hero} strokeWidth="5" strokeLinecap="round" fill="none" /></svg>
);

export const S04: React.FC = () => {
  const { T, frame } = useSc();
  const tA = T(ev(9, 0) - LEAD), outA = T(ev(10, 0.78));
  const spin = frame * 5;
  const tW = T(ev(10, 0.45));
  const tB = T(ev(10, 0.78) - LEAD);
  const tF = T(ev(11, 0.25));
  const wrongName = ip(T(ev(10, 0.85)), 0, 6, 0, 1), wrongFat = ip(tF, 0, 6, 0, 1);
  return (
    <>
      {/* conversion: ordinary card -> smart card */}
      <In t={tA} out={outA} x={-100} y={0} style={{ left: 110, top: 330 }}>
        <div style={{ width: 600, height: 380, borderRadius: 26, background: C.paper, boxShadow: `0 28px 60px -18px ${C.shadow}`, padding: 28, position: "relative" }}>
          <Tx size={44} color={C.ink} align="left">জাতীয় পরিচয়পত্র</Tx>
          {[0.7, 0.5, 0.62].map((w, i) => <div key={i} style={{ height: 16, width: `${w * 100}%`, borderRadius: 8, background: "rgba(20,32,26,0.22)", marginTop: 26 }} />)}
          <div style={{ position: "absolute", right: 28, bottom: 28 }}><Chip text="সাধারণ কার্ড" size={30} color={C.ink} fill="transparent" /></div>
        </div>
      </In>
      <In t={tA - 8} out={outA} s={0.3} cfg={theme.spring.bouncy} style={{ left: 840, top: 420 }}>
        <div style={{ width: 240, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
          <div style={{ transform: `rotate(${spin}deg)` }}><Gear size={110} color={C.warn} /></div>
          <Chip text="convert" mono size={34} color={C.warn} />
        </div>
      </In>
      <In t={tA - 14} out={outA} x={100} style={{ left: 1210, top: 330 }}><NidCard w={600} h={380} name="মোছাঃ মাকমুদা বেগম" father="ডাঃ আবুল হাসেম" /></In>
      <In t={tW} out={outA} s={0.2} cfg={theme.spring.bouncy} style={{ left: 1440, top: 250 }}><div style={{ transform: `rotate(${Math.sin(frame / 3) * 4}deg)` }}><Ico d={D.warn} size={150} color={C.warn} sw={3.2} /></div></In>
      {/* comparison: correct vs wrong */}
      <In t={tB} x={-140} style={{ left: 120, top: 360 }}>
        <NidCard w={700} h={420} name="মোছাঃ মাকমুদা বেগম" father="ডাঃ আবুল হাসেম" ok={ip(T(ev(10, 0.78)), 10, 20, 0, 1)} okF={ip(tF, 0, 6, 0, 1)} />
      </In>
      <In t={tB - 4} y={-20} style={{ left: 120, top: 276 }}><Chip text="সঠিক" size={42} color={C.accent} /></In>
      <In t={tB - 6} s={0.3} cfg={theme.spring.bouncy} style={{ left: 900, top: 460 }}><NotEq /></In>
      <In t={tB - 4} x={140} style={{ left: 1100, top: 360 }}>
        <NidCard w={700} h={420} name={wrongName > 0.5 ? "মোছাঃ মাখমুদা বেগম" : "মোছাঃ মাকমুদা বেগম"} father={wrongFat > 0.5 ? "ডাঃ আবুল হোসেন" : "ডাঃ আবুল হাসেম"} wrong={wrongName} wrongF={wrongFat} />
      </In>
      <In t={tB - 8} y={-20} style={{ left: 1100, top: 276 }}><Chip text="ভুল" size={42} color={C.hero} /></In>
      <In t={T(ev(10, 0.9))} s={0.4} y={20} style={{ left: 1050, top: 800 }}><Chip text="ক বনাম খ" size={34} color={C.hero} /></In>
      <In t={tF + 4} s={0.4} y={20} style={{ left: 1390, top: 800 }}><Chip text="হাসেম বনাম হোসেন" size={34} color={C.hero} /></In>
    </>
  );
};
