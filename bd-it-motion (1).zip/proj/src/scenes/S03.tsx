import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc, useSp } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { Cert, Ico, D, NidCard, Padlock } from "../graphics/g";

const C = theme.colors;
const Person: React.FC<{ label: string; w: number; h: number; badge?: string; color?: string }> = ({ label, w, h, badge, color = C.accent }) => (
  <Card w={w} h={h} border={color}>
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 26 }}>
      <div style={{ width: 120, height: 120, borderRadius: "50%", background: C.panel2, border: `4px solid ${color}`, display: "flex", alignItems: "center", justifyContent: "center" }}><Ico d={D.user} size={78} color={color} /></div>
      <Tx size={52} style={{ marginTop: 14 }}>{label}</Tx>
      {badge && <Chip text={badge} size={30} mono color={C.warn} style={{ marginTop: 12 }} />}
    </div>
  </Card>
);
const Pocket: React.FC<{ w: number; h: number }> = ({ w, h }) => (
  <svg width={w} height={h} viewBox="0 0 400 300">
    <path d="M10 10 H390 V190 C390 260 300 290 200 290 C100 290 10 260 10 190 Z" fill="#1F3F33" stroke={C.accentDim} strokeWidth="6" />
    <path d="M30 30 H370 V186 C370 246 290 270 200 270 C110 270 30 246 30 186 Z" fill="none" stroke={C.dim} strokeWidth="3" strokeDasharray="12 10" />
    <rect x="0" y="0" width="400" height="26" rx="10" fill="#2A5646" />
  </svg>
);

export const S03: React.FC = () => {
  const { T, frame } = useSc();
  const sp = useSp();
  const tA = T(ev(6, 0) - LEAD), outChain = T(ev(7, 0.5));
  const arr = ip(T(ev(6, 0.28)), 0, 22, 0, 1);
  const tN = T(ev(7, 0.55) - LEAD), outN = T(ev(8, 0.42));
  const slide = ip(T(ev(8, 0.42)), 0, 22, 0, 1, theme.ease.inOut);
  const q = T(ev(8, 0.5));
  return (
    <>
      {/* chain: parents first, then me */}
      <In t={tA} out={outChain} x={-90} style={{ left: 140, top: 300 }}><Person label="বাবা" w={400} h={380} badge="৫০-এর ঘর" /></In>
      <In t={tA - 5} out={outChain - 2} x={-90} style={{ left: 590, top: 300 }}><Person label="মা" w={400} h={380} badge="৫০-এর ঘর" /></In>
      <In t={T(ev(6, 0.55))} out={outChain - 3} x={90} style={{ left: 1270, top: 300 }}><Person label="আমি" w={460} h={380} color={C.hero} /></In>
      {/* small certificates + padlock on mine */}
      <In t={T(ev(6, 0.3))} out={outChain} y={20} style={{ left: 225, top: 700 }}><Cert w={230} h={140} title="অনলাইন" sub="" seal={false} /></In>
      <In t={T(ev(6, 0.34))} out={outChain} y={20} style={{ left: 675, top: 700 }}><Cert w={230} h={140} title="অনলাইন" sub="" seal={false} /></In>
      <In t={T(ev(6, 0.6))} out={outChain} y={20} style={{ left: 1385, top: 700 }}><div style={{ position: "relative" }}><Cert w={230} h={140} title="আমারটা" sub="" seal={false} dim /><div style={{ position: "absolute", left: 85, top: 40 }}><Padlock size={80} /></div></div></In>
      <svg style={{ position: "absolute", left: 0, top: 0, opacity: ip(outChain, 0, 9, 1, 0, theme.ease.in) }} width={1920} height={1080}>
        <path d="M1020 490 H1230" stroke={C.accent} strokeWidth="8" strokeLinecap="round" strokeDasharray="250" strokeDashoffset={(1 - arr) * 250} />
        <path d="M1196 462 L1232 490 L1196 518" fill="none" stroke={C.accent} strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" opacity={arr > 0.9 ? 1 : 0} />
      </svg>
      <In t={T(ev(7, 0) - 2)} out={outChain} s={0.4} cfg={theme.spring.bouncy} style={{ left: 1040, top: 380 }}><div style={{ width: 150, height: 90, display: "flex", alignItems: "center", justifyContent: "center" }}><Chip text="আগে" size={34} color={C.warn} /></div></In>
      {/* smart NID flies in: "chip লাগানো" */}
      <In t={tN} y={60} s={0.7} rot={-6} cfg={theme.spring.bouncy} style={{ left: 600, top: 260 }}>
        <div style={{ transform: `translateY(${slide * 150}px) scale(${1 - slide * 0.5}) rotate(${slide * 5}deg)` }}>
          <NidCard w={720} h={450} />
        </div>
      </In>
      <In t={T(ev(7, 0.75))} out={outN} x={60} s={0.6} style={{ left: 1400, top: 330 }}><Chip text="chip" mono size={46} color={C.warn} /></In>
      <svg style={{ position: "absolute", left: 0, top: 0, opacity: sp(T(ev(7, 0.75)), theme.spring.snappy) * (outN > 0 ? 0 : 1) }} width={1920} height={1080}>
        <path d="M1400 382 C1300 382 1200 400 1060 440" stroke={C.warn} strokeWidth="4" strokeDasharray="10 8" fill="none" />
      </svg>
      {/* pocket */}
      <In t={T(ev(8, 0.2) - LEAD)} y={80} style={{ left: 710, top: 560 }}><Pocket w={500} h={290} /></In>
      <In t={T(ev(8, 0.05))} x={-80} style={{ left: 150, top: 380 }}><Card w={430} h={330}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, paddingTop: 34 }}><Ico d={D.shield} size={110} color={C.accent} /><Tx size={50}>সরকারের দেওয়া</Tx><Chip text="smart NID" mono size={34} color={C.warn} /></div></Card></In>
      <In t={q} s={0.3} cfg={theme.spring.bouncy} style={{ left: 1300, top: 380 }}><Tx size={220} color={C.hero}>?</Tx></In>
    </>
  );
};
