import React from "react";
import { theme } from "../theme";
import { ev, LEAD } from "../anchors";
import { In, ip, useSc } from "../components/anim";
import { Card, Chip, Tx } from "../components/ui";
import { BigNum, Laptop, Padlock } from "../graphics/g";

const C = theme.colors;
const Wifi: React.FC<{ off?: boolean }> = ({ off }) => (
  <svg width="130" height="130" viewBox="0 0 48 48"><path d="M5 18 a27 27 0 0 1 38 0 M11 25 a18 18 0 0 1 26 0 M17 32 a9 9 0 0 1 14 0" stroke={C.cool} strokeWidth="4" fill="none" strokeLinecap="round" /><circle cx="24" cy="38" r="2.6" fill={C.cool} />{off && <path d="M8 6 L40 42" stroke={C.hero} strokeWidth="5" strokeLinecap="round" />}</svg>
);
const Bar: React.FC<{ h: number; w: number; color: string; label: string; val: string }> = ({ h, w, color, label, val }) => (
  <div style={{ width: w, display: "flex", flexDirection: "column", alignItems: "center" }}>
    <Tx size={46} color={color} style={{ marginBottom: 10 }}>{val}</Tx>
    <div style={{ width: w * 0.6, height: h, borderRadius: "16px 16px 0 0", background: `linear-gradient(180deg, ${color}, ${color}88)`, boxShadow: `0 0 30px ${color}55` }} />
    <div style={{ width: w, height: 6, background: C.line }} />
    <Tx size={40} style={{ marginTop: 10, whiteSpace: "nowrap" }}>{label}</Tx>
  </div>
);

export const S08: React.FC = () => {
  const { T, frame } = useSc();
  const outA = T(ev(22, 0.3)), outB = T(ev(24, 0)), outBar = T(ev(23, 0.58));
  const count = ip(T(ev(21, 0.78)), 0, 46, 0, 4211);
  const grow = ip(T(ev(22, 0.78)), 0, 26, 0, 1, theme.ease.out);
  const tL = T(ev(24, 0.35));
  const lockS = ip(tL, 0, 7, 3, 1);
  return (
    <>
      {/* title + the amount */}
      <In t={T(ev(21, 0.3) - LEAD)} out={outA} x={-100} style={{ left: 150, top: 300 }}>
        <Card w={640} h={440} glow="acc"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 18, paddingTop: 40 }}>
          <Laptop w={300} />
          <Tx size={58}>শেখ রাসেল</Tx><Chip text="digital lab project" mono size={36} color={C.accent} />
        </div></Card>
      </In>
      <In t={T(ev(21, 0.78) - LEAD)} out={outA} x={100} style={{ left: 880, top: 330 }}>
        <Card w={880} h={380} glow="hero"><div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", gap: 14 }}>
          <Tx size={44} color={C.dim}>খরচ হয়েছে প্রায়</Tx>
          <BigNum v={count} size={170} color={C.hero} />
          <Tx size={62}>কোটি টাকা</Tx>
        </div></Card>
      </In>
      {/* market price vs syndicate price */}
      <In t={T(ev(22, 0.3) - LEAD)} out={outBar} y={40} style={{ left: 330, top: 280 }}>
        <Card w={1260} h={570}><div style={{ position: "absolute", left: 80, bottom: 40, display: "flex", alignItems: "flex-end", gap: 120 }}>
          <Bar w={320} h={120} color={C.accent} label="বাজারদর" val="১ গুণ" />
          <Bar w={320} h={120 + 180 * grow} color={C.hero} label="syndicate-এর দাম" val={grow > 0.5 ? "২ থেকে ৩ গুণ" : "?"} />
        </div>
        </Card>
      </In>
      <In t={T(ev(23, 0.05))} out={outBar} s={0.4} cfg={theme.spring.bouncy} style={{ left: 1190, top: 330 }}><Chip text="নিম্নমানের laptop" size={42} color={C.warn} /></In>
      <In t={T(ev(23, 0.1))} out={outBar} y={20} style={{ left: 1250, top: 470 }}><Laptop w={260} color={C.warn} /></In>
      <In t={T(ev(23, 0.62) - LEAD)} out={outB} x={-60} style={{ left: 400, top: 360 }}><Card w={400} h={340}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 30 }}><Wifi off /><Tx size={46}>internet নেই</Tx></div></Card></In>
      <In t={T(ev(23, 0.74) - LEAD)} out={outB} x={60} style={{ left: 1120, top: 360 }}><Card w={400} h={340}><div style={{ display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 30 }}><svg width="130" height="130" viewBox="0 0 48 48"><path d="M24 22a8 8 0 1 0 0.01 0 M8 42 C8 32 16 28 24 28 C32 28 40 32 40 42" stroke={C.warn} strokeWidth="4" fill="none" strokeLinecap="round" /><path d="M8 6 L40 42" stroke={C.hero} strokeWidth="5" strokeLinecap="round" /></svg><Tx size={46}>শিক্ষক নেই</Tx></div></Card></In>
      {/* locked storehouse */}
      <In t={T(ev(24, 0) - LEAD)} y={50} style={{ left: 440, top: 300 }}>
        <svg width="1040" height="520" viewBox="0 0 520 260">
          <path d="M20 120 L260 20 L500 120 V250 H20 Z" fill="#3A4C45" stroke="#5B6E66" strokeWidth="4" />
          <rect x="130" y="130" width="260" height="120" fill="#22312B" />
          {[0, 1, 2, 3, 4, 5].map((i) => <rect key={i} x="130" y={136 + i * 19} width="260" height="9" fill="#2D4037" />)}
          <path d="M20 120 L260 20 L500 120" fill="none" stroke={C.hero} strokeWidth="6" />
        </svg>
      </In>
      <div style={{ position: "absolute", left: 800, top: 500, transform: `scale(${lockS})`, opacity: ip(tL, 0, 3, 0, 1) }}><Padlock size={320} /></div>
      <In t={T(ev(24, 0.1))} s={0.5} y={-10} style={{ left: 1200, top: 300 }}><Chip text="তালাবদ্ধ" size={58} color={C.hero} /></In>
    </>
  );
};
