// theme.ts - single source of truth (Scheme 2: "Bangladesh Night"). Never inline colors/easings elsewhere.
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#07130F",
    bgAlt: "#0C1F18",
    panel: "#0F2A20",
    panel2: "#163A2B",
    line: "rgba(242,248,244,0.16)",
    hero: "#F42A41", // THE hero (flag red) - sparingly
    heroDim: "#A8202F",
    accent: "#2ECC8F", // green
    accentDim: "#1C8A62",
    text: "#F2F8F4",
    dim: "#8FB3A3",
    paper: "#EDEBDD",
    ink: "#14201A",
    // functional colors (heat / warning), independent of the scheme
    cool: "#4DA3FF",
    warn: "#FFC857",
    glowHero: "rgba(244,42,65,0.38)",
    glowAcc: "rgba(46,204,143,0.30)",
    shadow: "rgba(0,0,0,0.55)",
  },
  fonts: {
    sans: "'VF','Nirmala UI','Vrinda','Noto Sans Bengali',sans-serif",
    mono: "'VM','VF','Nirmala UI',monospace",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    soft: Easing.bezier(0.33, 1, 0.68, 1),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  W: 1920,
  H: 1080,
  L: {
    margin: 60,
    capTopY: 30, capH: 188, // top caption band
    capBotY: 862, // bottom caption band (h 188)
    visTop: 240, visBot: 852, // visual zone
    progressY: 1066,
  },
} as const;

export const bn = (s: string | number) => String(s).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[+d]);
