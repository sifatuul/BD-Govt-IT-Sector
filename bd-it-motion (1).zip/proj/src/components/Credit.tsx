import React from "react";
import { Img, staticFile, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { CREDIT_FRAMES } from "../anchors";
import { ip, useSp, clamp } from "./anim";
import { Chip, Tx, heavy } from "./ui";

// ---- ending credit (small, centered) ----
export const CREDIT = { name: "Md Sifatul Islam", tag: "student of Materials Science", by: "Created by", file: "creator.png" };
const SCALE = 0.4; // only this changes if the user wants it bigger/smaller (base size = 100%)
const BASE = { photo: 600, nameSize: 104 };

const Star: React.FC<{ a: number; r: number; size: number; ph: number }> = ({ a, r, size, ph }) => {
  const f = useCurrentFrame();
  const ang = ((a + f * 0.9) * Math.PI) / 180;
  const pulse = 0.55 + 0.45 * Math.sin(f / 5 + ph);
  return (
    <svg width={size} height={size} viewBox="-10 -10 20 20" style={{ position: "absolute", left: Math.cos(ang) * r - size / 2, top: Math.sin(ang) * r - size / 2, opacity: pulse, transform: `scale(${0.6 + pulse * 0.6})` }}>
      <path d="M0 -9 L2 -2 L9 0 L2 2 L0 9 L-2 2 L-9 0 L-2 -2 Z" fill={ph % 2 ? theme.colors.accent : theme.colors.warn} />
    </svg>
  );
};

export const CreditScene: React.FC<{ total?: number }> = ({ total = CREDIT_FRAMES }) => {
  const f = useCurrentFrame(); // local 0..CREDIT_FRAMES
  const sp = useSp();
  const exit = theme.ease.in(clamp((f - (total - 14)) / 14)); // pop-out, last 14 frames
  const G = SCALE * (1 - exit);
  const popP = sp(f - 6, theme.spring.bouncy);
  const chipP = sp(f - 2, theme.spring.snappy);
  const tagP = sp(f - 36, theme.spring.snappy);
  const parts = CREDIT.name.split(" ");
  const D = BASE.photo;
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <div style={{ position: "absolute", left: 960, top: 540, width: 0, height: 0, transform: `scale(${G})`, transformOrigin: "0px 0px" }}>
        {/* Created by chip */}
        <div style={{ position: "absolute", left: -300, width: 600, top: -D / 2 - 250, display: "flex", justifyContent: "center", opacity: chipP, transform: `translateY(${(1 - chipP) * 40}px)` }}>
          <Chip text={CREDIT.by} size={52} mono color={theme.colors.accent} />
        </div>
        {/* photo pop-up */}
        <div style={{ position: "absolute", left: -D / 2, top: -D / 2 - 40, width: D, height: D, transform: `scale(${popP}) rotate(${(1 - popP) * -14}deg)` }}>
          <div style={{ position: "absolute", inset: -26, borderRadius: "50%", boxShadow: `0 0 120px ${theme.colors.glowHero}, 0 0 60px ${theme.colors.glowAcc}` }} />
          <svg width={D + 120} height={D + 120} viewBox="0 0 100 100" style={{ position: "absolute", left: -60, top: -60, transform: `rotate(${f * 2.2}deg)` }}>
            <circle cx="50" cy="50" r="48.5" fill="none" stroke={theme.colors.accent} strokeWidth="0.55" strokeDasharray="3 2.6" strokeLinecap="round" />
          </svg>
          <Img src={staticFile(CREDIT.file)} style={{ width: D, height: D, borderRadius: "50%", objectFit: "cover", objectPosition: "50% 30%", border: `12px solid ${theme.colors.hero}`, boxSizing: "border-box", display: "block" }} />
          <div style={{ position: "absolute", left: D / 2, top: D / 2 }}>
            {[0, 60, 120, 180, 240, 300].map((a, i) => <Star key={i} a={a + 20} r={D / 2 + 50 + (i % 2) * 22} size={i % 2 ? 40 : 56} ph={i} />)}
          </div>
        </div>
        {/* name: word by word, last word accent */}
        <div style={{ position: "absolute", left: -700, width: 1400, top: D / 2 + 30, display: "flex", justifyContent: "center", columnGap: 30, fontFamily: theme.fonts.sans, fontSize: BASE.nameSize, fontWeight: 700, lineHeight: 1.2 }}>
          {parts.map((w, i) => {
            const p = sp(f - 18 - i * 5, theme.spring.snappy);
            return <span key={i} style={{ display: "inline-block", opacity: clamp(p * 1.5), transform: `translateY(${(1 - p) * 40}px) scale(${0.85 + 0.15 * p})`, color: i === parts.length - 1 ? theme.colors.accent : theme.colors.text, ...heavy(BASE.nameSize) }}>{w}</span>;
          })}
        </div>
        {/* mini tag */}
        <div style={{ position: "absolute", left: -600, width: 1200, top: D / 2 + 190, display: "flex", justifyContent: "center", opacity: tagP, transform: `translateY(${(1 - tagP) * 30}px)` }}>
          <Chip text={CREDIT.tag} size={46} mono color={theme.colors.text} />
        </div>
      </div>
    </div>
  );
};
