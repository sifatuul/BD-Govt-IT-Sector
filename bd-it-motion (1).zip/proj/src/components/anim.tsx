import React, { createContext, useContext } from "react";
import { Easing, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

export const SceneCtx = createContext({ from: 0, to: 1 });

/** T(g) = frames elapsed since global frame g (negative = not yet). */
export function useSc() {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const sc = useContext(SceneCtx);
  const T = (g: number) => frame - (g - sc.from);
  return { frame, fps, sc, T, g: frame + sc.from };
}

type Cfg = { damping: number; stiffness: number; mass: number };
export const useSp = () => {
  const { fps } = useVideoConfig();
  return (t: number, cfg: Cfg = theme.spring.smooth) => (t <= 0 ? 0 : spring({ frame: t, fps, config: cfg }));
};

export const ip = (t: number, a: number, b: number, x: number, y: number, e: (n: number) => number = theme.ease.out) =>
  interpolate(t, [a, b], [x, y], { easing: e, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

export const clamp = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));

type InProps = {
  t: number; out?: number; x?: number; y?: number; s?: number; rot?: number; cfg?: Cfg;
  style?: React.CSSProperties; children?: React.ReactNode; idle?: number; fade?: number;
};
/** Entrance: opacity + translate + scale together; optional faster exit (out = frames since exit start). */
export const In: React.FC<InProps> = ({ t, out, x = 0, y = 36, s = 0.92, rot = 0, cfg = theme.spring.smooth, style, children, idle = 0, fade = 1 }) => {
  const sp = useSp();
  const frame = useCurrentFrame();
  const p = sp(t, cfg);
  const o = out === undefined ? 0 : theme.ease.in(clamp(out / 9));
  const br = idle ? Math.sin(frame / 24 + idle) * 4 : 0;
  return (
    <div
      style={{
        position: "absolute",
        opacity: clamp(p * 1.4) * (1 - o) * fade,
        transform: `translate(${x * (1 - p)}px, ${y * (1 - p) - o * 18 + br}px) scale(${(s + (1 - s) * p) * (1 - 0.05 * o)}) rotate(${rot * (1 - p)}deg)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Words, staggered (never splits Bengali letters; splits on spaces only). */
export const Words: React.FC<{ text: string; t: number; per?: number; size: number; color?: string; accent?: number[]; weight?: number; align?: "center" | "left" | "right"; gap?: number; style?: React.CSSProperties }> = ({
  text, t, per = 4, size, color = theme.colors.text, accent = [], weight = 700, align = "center", gap = 16, style,
}) => {
  const sp = useSp();
  return (
    <div style={{ display: "flex", flexWrap: "wrap", justifyContent: align === "center" ? "center" : align === "left" ? "flex-start" : "flex-end", columnGap: gap, fontFamily: theme.fonts.sans, fontSize: size, fontWeight: weight, color, lineHeight: 1.18, ...style }}>
      {text.split(" ").map((w, i) => {
        const p = sp(t - i * per, theme.spring.snappy);
        return (
          <span key={i} style={{ display: "inline-block", opacity: clamp(p * 1.5), transform: `translateY(${(1 - p) * 26}px) scale(${0.9 + 0.1 * p})`, color: accent.includes(i) ? theme.colors.accent : color, whiteSpace: "nowrap" }}>
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** hidden warm-up so each weight/script is rasterized once */
export const FontWarmup: React.FC = () => (
  <div style={{ position: "absolute", left: -4000, top: 0, opacity: 0, fontFamily: theme.fonts.sans }}>
    {[400, 500, 700].map((w) => (
      <span key={w} style={{ fontWeight: w }}>Abc 123 জন্ম নিবন্ধন কংক্রিট দুঃখ ‌‍ ৳</span>
    ))}
    <span style={{ fontFamily: theme.fonts.mono, fontWeight: 700 }}>Abc 123 নিবন্ধন</span>
  </div>
);

export const easeIn = Easing.bezier(0.7, 0, 0.84, 0);
