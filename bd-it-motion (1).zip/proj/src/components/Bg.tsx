import React from "react";
import { AbsoluteFill, random, useCurrentFrame } from "remotion";
import { theme } from "../theme";

export const BgMesh: React.FC = () => {
  const f = useCurrentFrame();
  const d1 = Math.sin(f / 90) * 70, d2 = Math.cos(f / 110) * 60;
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${theme.colors.bg}, ${theme.colors.bgAlt})` }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -640, left: -380 + d1, filter: "blur(60px)", background: `radial-gradient(circle, ${theme.colors.accent}30, transparent 64%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -560, right: -260 - d2, filter: "blur(70px)", background: `radial-gradient(circle, ${theme.colors.hero}26, transparent 66%)` }} />
      <div style={{ position: "absolute", width: 800, height: 800, borderRadius: "50%", top: 120 + d2, right: 120, filter: "blur(80px)", background: `radial-gradient(circle, ${theme.colors.accent}14, transparent 66%)` }} />
    </AbsoluteFill>
  );
};

export const Grid: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        opacity: 0.07, backgroundSize: "96px 96px", backgroundPosition: `${(f * 0.25) % 96}px ${(f * 0.4) % 96}px`,
        backgroundImage: `linear-gradient(${theme.colors.text} 1px, transparent 1px), linear-gradient(90deg, ${theme.colors.text} 1px, transparent 1px)`,
        WebkitMaskImage: "radial-gradient(ellipse at center, #000 30%, transparent 78%)", maskImage: "radial-gradient(ellipse at center, #000 30%, transparent 78%)",
      }}
    />
  );
};

export const Particles: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {Array.from({ length: 30 }).map((_, i) => {
        const sp = 0.25 + random(`s${i}`) * 0.6;
        const x = random(`x${i}`) * theme.W + Math.sin(f / 60 + i) * 16;
        const y = (((random(`y${i}`) * theme.H - f * sp) % theme.H) + theme.H) % theme.H;
        const r = 2 + random(`r${i}`) * 4;
        return <div key={i} style={{ position: "absolute", left: x, top: y, width: r * 2, height: r * 2, borderRadius: "50%", background: i % 5 === 0 ? theme.colors.hero : theme.colors.accent, opacity: 0.12 + random(`o${i}`) * 0.2 }} />;
      })}
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.accent, mixBlendMode: "soft-light", opacity: 0.16 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 26%, transparent 74%, rgba(0,0,0,0.22))" }} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const f = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(f * 7) % 220}px ${(f * 13) % 220}px`, opacity: 0.05, mixBlendMode: "overlay" }} />;
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.38) 100%)" }} />
);
