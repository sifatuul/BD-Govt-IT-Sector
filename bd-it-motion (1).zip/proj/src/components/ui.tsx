import React from "react";
import { theme } from "../theme";
import { BENGALI_FONT } from "../fontData";

// FreeSans (fallback Bengali font) has no bold: fake weight with a hairline stroke. Real Hind Siliguri needs none.
const FAUX = BENGALI_FONT.startsWith("FreeSans");
export const heavy = (size: number, weight = 700): React.CSSProperties =>
  FAUX && weight >= 600 ? { WebkitTextStroke: `${(size * 0.022).toFixed(2)}px currentColor` } : {};

export const Abs: React.FC<{ x: number; y: number; w?: number; h?: number; style?: React.CSSProperties; children?: React.ReactNode }> = ({ x, y, w, h, style, children }) => (
  <div style={{ position: "absolute", left: x, top: y, width: w, height: h, ...style }}>{children}</div>
);

export const Tx: React.FC<{ size: number; color?: string; weight?: number; align?: React.CSSProperties["textAlign"]; mono?: boolean; style?: React.CSSProperties; children?: React.ReactNode }> = ({
  size, color = theme.colors.text, weight = 700, align = "center", mono, style, children,
}) => (
  <div style={{ fontFamily: mono ? theme.fonts.mono : theme.fonts.sans, fontSize: size, fontWeight: weight, color, textAlign: align, lineHeight: 1.2, ...heavy(size, weight), ...style }}>{children}</div>
);

export const Card: React.FC<{ w: number; h: number; tone?: "panel" | "paper" | "dark"; glow?: "hero" | "acc" | null; border?: string; style?: React.CSSProperties; children?: React.ReactNode }> = ({
  w, h, tone = "panel", glow = null, border, style, children,
}) => (
  <div
    style={{
      width: w, height: h, borderRadius: 26, position: "relative", overflow: "hidden",
      background: tone === "paper" ? theme.colors.paper : tone === "dark" ? theme.colors.bg : `linear-gradient(160deg, ${theme.colors.panel2}, ${theme.colors.panel})`,
      border: `2px solid ${border ?? (tone === "paper" ? "rgba(0,0,0,0.08)" : theme.colors.line)}`,
      boxShadow: `0 30px 60px -20px ${theme.colors.shadow}${glow ? `, 0 0 50px ${glow === "hero" ? theme.colors.glowHero : theme.colors.glowAcc}` : ""}`,
      ...style,
    }}
  >
    {children}
  </div>
);

export const Chip: React.FC<{ text: string; color?: string; size?: number; mono?: boolean; fill?: string; style?: React.CSSProperties }> = ({
  text, color = theme.colors.accent, size = 30, mono = false, fill, style,
}) => (
  <div
    style={{
      display: "inline-flex", alignItems: "center", gap: 10, padding: `${size * 0.28}px ${size * 0.7}px`, borderRadius: 999,
      border: `2px solid ${color}`, background: fill ?? "rgba(7,19,15,0.72)", color, fontFamily: mono ? theme.fonts.mono : theme.fonts.sans,
      fontSize: size, fontWeight: 700, whiteSpace: "nowrap", ...heavy(size * 0.6), ...style,
    }}
  >
    {text}
  </div>
);

export const Dot: React.FC<{ c: string; r?: number }> = ({ c, r = 7 }) => (
  <div style={{ width: r * 2, height: r * 2, borderRadius: "50%", background: c, boxShadow: `0 0 14px ${c}` }} />
);
