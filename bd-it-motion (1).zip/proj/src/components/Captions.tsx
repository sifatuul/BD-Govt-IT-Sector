import React from "react";
import { useCurrentFrame } from "remotion";
import { HEADLINES, Word } from "../headlines";
import { theme } from "../theme";
import { clamp, ip, useSp } from "./anim";
import { heavy } from "./ui";

const sizeFor = (words: Word[]) => {
  const chars = words.reduce((a, w) => a + w.t.length, 0) + words.length - 1;
  if (chars <= 13) return 98;
  if (chars <= 20) return 90;
  if (chars <= 27) return 82;
  if (chars <= 34) return 74;
  if (chars <= 42) return 66;
  return 60;
};

const Band: React.FC<{ words: Word[]; t: number; y: number; delay: number }> = ({ words, t, y, delay }) => {
  const sp = useSp();
  const size = sizeFor(words);
  return (
    <div style={{ position: "absolute", left: theme.L.margin, width: theme.W - theme.L.margin * 2, top: y, height: theme.L.capH, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", alignItems: "center", columnGap: size * 0.26, rowGap: 2, fontFamily: theme.fonts.sans, fontSize: size, fontWeight: 700, lineHeight: 1.16, maxWidth: 1760 }}>
        {words.map((w, i) => {
          const p = sp(t - delay - i * 4, theme.spring.snappy);
          const c = w.k === "a" ? theme.colors.accent : w.k === "h" ? theme.colors.hero : theme.colors.text;
          return (
            <span key={i} style={{ display: "inline-block", whiteSpace: "nowrap", color: c, opacity: clamp(p * 1.6), transform: `translateY(${(1 - p) * 28}px) scale(${0.9 + 0.1 * p})`, textShadow: `0 4px 22px ${theme.colors.shadow}, 0 0 2px rgba(0,0,0,0.9)`, ...heavy(size) }}>
              {w.t}
            </span>
          );
        })}
      </div>
    </div>
  );
};

export const Captions: React.FC = () => {
  const f = useCurrentFrame();
  const cur = HEADLINES.find((h) => f >= h.from && f <= h.until);
  const L = theme.L;
  if (!cur) return null;
  const t = f - cur.from;
  const out = ip(f, cur.until - 5, cur.until, 1, 0, theme.ease.in);
  const topN = cur.top.length;
  return (
    <div style={{ position: "absolute", inset: 0, opacity: out }}>
      <div style={{ position: "absolute", left: 0, top: 0, width: theme.W, height: L.capTopY + L.capH + 14, background: `linear-gradient(180deg, rgba(7,19,15,0.88), rgba(7,19,15,0.55) 70%, transparent)` }} />
      <div style={{ position: "absolute", left: 0, top: L.capBotY - 14, width: theme.W, height: theme.H - L.capBotY + 14, background: `linear-gradient(0deg, rgba(7,19,15,0.9), rgba(7,19,15,0.58) 70%, transparent)` }} />
      <Band words={cur.top} t={t} y={L.capTopY} delay={0} />
      <Band words={cur.bottom} t={t} y={L.capBotY} delay={topN * 4 + 3} />
    </div>
  );
};

export const Progress: React.FC<{ total: number }> = ({ total }) => {
  const f = useCurrentFrame();
  const w = (f / total) * (theme.W - 120);
  return (
    <div style={{ position: "absolute", left: 60, top: theme.L.progressY, width: theme.W - 120, height: 6, borderRadius: 3, background: "rgba(242,248,244,0.1)" }}>
      <div style={{ width: w, height: 6, borderRadius: 3, background: `linear-gradient(90deg, ${theme.colors.accent}, ${theme.colors.accent})` }} />
      <div style={{ position: "absolute", left: w - 7, top: -4, width: 14, height: 14, borderRadius: "50%", background: theme.colors.hero, boxShadow: `0 0 14px ${theme.colors.hero}` }} />
    </div>
  );
};
