import React from "react";
import { useCurrentFrame } from "remotion";
import { SCENE_LIST, MAIN_END, END_CUT } from "../anchors";
import { theme } from "../theme";
import { ip } from "./anim";

const BOUNDS = [...SCENE_LIST.slice(1).map((s) => s.from), MAIN_END + END_CUT];
/** brand band that sweeps across every scene boundary; the cut happens behind it at p = 0.5 */
export const Transition: React.FC = () => {
  const f = useCurrentFrame();
  const B = BOUNDS.find((b) => f >= b - 10 && f <= b + 10);
  if (B === undefined) return null;
  const p = ip(f, B - 10, B + 10, 0, 1, theme.ease.inOut);
  const x = -3400 + p * 5720;
  return (
    <div style={{ position: "absolute", left: x, top: -120, width: 3000, height: 1320, transform: "skewX(-12deg)", background: `linear-gradient(90deg, ${theme.colors.bg}, ${theme.colors.panel} 70%, ${theme.colors.panel2})`, borderRight: `22px solid ${theme.colors.hero}`, boxShadow: `18px 0 0 0 ${theme.colors.accent}, -40px 0 80px ${theme.colors.shadow}` }} />
  );
};
