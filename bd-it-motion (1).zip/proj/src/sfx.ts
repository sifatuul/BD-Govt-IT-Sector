// sfx.ts - SFX cue sheet, all derived from SRT anchors (frame = event - 2, i.e. just before the visual).
// Quiet by design: files are synthesized soft (low-passed, smooth envelopes); volumes keep them well under the voice.
import { ev, SCENE_LIST, MAIN_END, END_CUT } from "./anchors";

export type Cue = { at: number; name: string; vol: number };
const V = { soft: 0.14, mid: 0.2, hit: 0.3 }; // effective peaks about -24 .. -16 dBFS; voice stays on top
const e = (c: number, f: number, name: string, vol = V.mid, lead = 2): Cue => ({ at: ev(c, f) - lead, name, vol });

export const SFX: Cue[] = [
  // scene transitions: soft whoosh as the brand band starts sweeping
  ...SCENE_LIST.slice(1).map((s) => ({ at: s.from - 11, name: "whoosh", vol: V.soft })),
  { at: MAIN_END - 1, name: "whoosh", vol: V.soft },
  // ending credit: pop (photo), ding (name done), whoosh out
  { at: MAIN_END + END_CUT + 4, name: "pop", vol: V.mid },
  { at: MAIN_END + END_CUT + 36, name: "ding", vol: V.soft },
  { at: MAIN_END + END_CUT + 82, name: "whoosh", vol: V.soft },
  // story beats
  e(1, 0, "pop", V.soft, 4), e(2, 0, "paper", V.soft, 5),
  e(4, 0.62, "stamp", V.hit), e(5, 0.28, "tick", V.soft, 1), e(5, 0.5, "pop", V.mid),
  e(7, 0.55, "pop", V.soft, 5), e(8, 0.42, "paper", V.soft),
  e(10, 0.82, "buzz", V.soft), e(11, 0.28, "buzz", V.soft),
  e(15, 0.9, "paper", V.soft), e(16, 0.74, "coin", V.mid), e(16, 0.78, "ding", V.soft, -4),
  e(18, 0.45, "pop", V.soft), e(20, 0.15, "coin", V.soft), e(20, 0.3, "coin", V.soft),
  e(21, 0.78, "swell", V.soft), e(22, 0.78, "pop", V.soft), e(24, 0.35, "thud", V.hit),
  e(25, 0.62, "swell", V.soft), e(26, 0.08, "paper", V.soft), e(28, 0, "thud", V.mid), e(29, 0, "pop", V.soft),
  e(31, 0.5, "stamp", V.mid), e(34, 0, "buzz", V.soft),
  e(36, 0.5, "tick", V.soft), e(37, 0.45, "buzz", V.mid), e(37, 0.45, "thud", V.mid), e(39, 0, "pop", V.soft), e(40, 0.2, "ding", V.soft), e(41, 0.3, "paper", V.soft),
  e(42, 0.55, "pop", V.soft), e(42, 0.67, "pop", V.soft), e(42, 0.79, "pop", V.soft),
  e(44, 0.38, "thud", V.mid), e(46, 0, "pop", V.soft), e(46, 0.15, "pop", V.soft), e(46, 0.6, "pop", V.soft),
  e(48, 0.36, "pop", V.mid), e(48, 0.4, "tick", V.soft), e(48, 0.55, "tick", V.soft), e(48, 0.7, "tick", V.soft), e(48, 0.82, "tick", V.soft), e(48, 0.92, "tick", V.soft),
  e(50, 0, "swell", V.soft), e(50, 0.1, "ding", V.soft),
  e(51, 0.5, "paper", V.soft), e(52, 0.58, "pop", V.soft), e(54, 0.15, "beep", V.soft), e(54, 0.37, "beep", V.soft), e(54, 0.59, "beep", V.soft), e(54, 0.55, "ding", V.mid),
  e(56, 0.62, "paper", V.mid), e(57, 0.55, "thud", V.mid), e(58, 0.12, "swell", V.soft), e(58, 0.74, "pop", V.mid), e(59, 0, "ding", V.mid),
];
