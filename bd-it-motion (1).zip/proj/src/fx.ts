// fx.ts - camera shake & flash events (all anchored on SRT cues)
import { ev } from "./anchors";

type E = { at: number; amp: number };
export const SHAKES: E[] = [
  { at: ev(4, 0.62), amp: 16 }, // stamp "বাতিল"
  { at: ev(10, 0.88), amp: 12 }, // wrong name
  { at: ev(11, 0.5), amp: 12 },
  { at: ev(16, 0.78), amp: 10 }, // approved
  { at: ev(24, 0.35), amp: 16 }, // lab locked
  { at: ev(28, 0.2), amp: 14 }, // concrete
  { at: ev(37, 0.45), amp: 18 }, // server down
  { at: ev(41, 0.55), amp: 12 },
  { at: ev(44, 0.35), amp: 14 }, // bricks stop
  { at: ev(58, 0.3), amp: 12 },
];
export const FLASHES: E[] = [
  { at: ev(4, 0.62), amp: 0.28 },
  { at: ev(16, 0.78), amp: 0.2 },
  { at: ev(24, 0.35), amp: 0.22 },
  { at: ev(37, 0.45), amp: 0.3 },
  { at: ev(59, 0.1), amp: 0.3 },
];
export const shakeAt = (f: number) => {
  let x = 0, y = 0;
  for (const s of SHAKES) {
    const dt = f - s.at;
    if (dt < 0 || dt > 22) continue;
    const d = Math.exp(-dt / 6) * s.amp;
    x += Math.sin(dt * 2.3) * d; y += Math.cos(dt * 3.1) * d * 0.7;
  }
  return { x, y };
};
export const flashAt = (f: number) => {
  let a = 0;
  for (const s of FLASHES) { const dt = f - s.at; if (dt >= 0 && dt < 10) a += s.amp * (1 - dt / 10) ** 2; }
  return Math.min(a, 0.5);
};
