import React, { useContext, useEffect, useState } from "react";
import { AbsoluteFill, Audio, Sequence, getRemotionEnvironment, staticFile, useCurrentFrame } from "remotion";
import { FONT_CSS } from "./fontData";
import { theme } from "./theme";
import { CREDIT_FRAMES, END_CUT, MAIN_END, SCENES, SCENE_LIST, TOTAL_FRAMES } from "./anchors";
import { flashAt, shakeAt } from "./fx";
import { SFX } from "./sfx";
import { BgMesh, Grade, Grain, Grid, Particles, Vignette } from "./components/Bg";
import { Captions, Progress } from "./components/Captions";
import { Transition } from "./components/Transition";
import { CreditScene } from "./components/Credit";
import { FontWarmup, SceneCtx, ip } from "./components/anim";
import { SCENE_COMPONENTS } from "./scenes";

const PREVIEW_VOICEOVER = true; // Studio preview plays public/voiceover.mp3 (silently skipped if the file is missing)

const SceneShell: React.FC<{ from: number; to: number; dy: number; children: React.ReactNode }> = ({ from, to, dy, children }) => {
  const f = useCurrentFrame();
  const sh = shakeAt(f + from);
  const zoom = 1 + 0.03 * ip(f, 0, to - from, 0, 1, theme.ease.soft);
  return (
    <SceneCtx.Provider value={{ from, to }}>
      <AbsoluteFill style={{ transform: `translate(${sh.x}px, ${sh.y + dy}px) scale(${zoom})`, transformOrigin: "50% 50%" }}>{children}</AbsoluteFill>
    </SceneCtx.Provider>
  );
};

const Flash: React.FC = () => {
  const a = flashAt(useCurrentFrame());
  return a > 0 ? <AbsoluteFill style={{ background: theme.colors.text, opacity: a, mixBlendMode: "soft-light", pointerEvents: "none" }} /> : null;
};

const Voice: React.FC<{ withVoiceover: boolean }> = ({ withVoiceover }) => {
  const env = getRemotionEnvironment();
  const [ok, setOk] = useState(false);
  useEffect(() => {
    if (env.isRendering) return;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" }).then((r) => setOk(r.ok)).catch(() => setOk(false));
  }, [env.isRendering]);
  const play = env.isRendering ? withVoiceover : PREVIEW_VOICEOVER && ok;
  if (!play) return null;
  return (
    <Sequence from={0} durationInFrames={MAIN_END}>
      <Audio src={staticFile("voiceover.mp3")} volume={1} />
    </Sequence>
  );
};

export const Main: React.FC<{ withVoiceover?: boolean }> = ({ withVoiceover = false }) => (
  <AbsoluteFill style={{ background: theme.colors.bg, overflow: "hidden", fontFamily: theme.fonts.sans }}>
    <style>{FONT_CSS}</style>
    <FontWarmup />
    <BgMesh />
    <Grid />
    <Particles />
    {SCENE_LIST.map((s) => {
      const S = SCENE_COMPONENTS[s.key];
      if (!S) return null;
      return (
        <Sequence key={s.key} from={s.from} durationInFrames={s.to - s.from + (s.to === MAIN_END ? END_CUT : 0)}>
          <SceneShell from={s.from} to={s.to + (s.to === MAIN_END ? END_CUT : 0)} dy={S.dy ?? 0}>
            <S.C />
          </SceneShell>
        </Sequence>
      );
    })}
    {CREDIT_FRAMES > 0 && (
      <Sequence from={SCENES.credit.from + END_CUT} durationInFrames={CREDIT_FRAMES - END_CUT}>
        <CreditScene total={CREDIT_FRAMES - END_CUT} />
      </Sequence>
    )}
    <Transition />
    <Captions />
    <Progress total={TOTAL_FRAMES} />
    <Grade />
    <Flash />
    <Grain />
    <Vignette />
    {SFX.map((c, i) => (
      <Sequence key={i} from={Math.max(0, c.at)} durationInFrames={90} layout="none">
        <Audio src={staticFile(`sfx/${c.name}.wav`)} volume={c.vol} />
      </Sequence>
    ))}
    <Voice withVoiceover={withVoiceover} />
  </AbsoluteFill>
);
