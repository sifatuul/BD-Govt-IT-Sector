import React from "react";
import { theme, bn } from "../theme";
import { Tx, heavy } from "../components/ui";

const C = theme.colors;

export const Ico: React.FC<{ d: string; size?: number; color?: string; sw?: number; fill?: string; style?: React.CSSProperties }> = ({ d, size = 48, color = C.text, sw = 4, fill = "none", style }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" style={style}><path d={d} fill={fill} stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" /></svg>
);
// glyphs drawn as SVG (the fonts have no check/arrow glyphs)
export const D = {
  check: "M10 25 L20 35 L38 13", cross: "M13 13 L35 35 M35 13 L13 35", arrow: "M8 24 H38 M26 12 L38 24 L26 36",
  warn: "M24 8 L42 40 H6 Z M24 20 V30 M24 35 V36", globe: "M24 6a18 18 0 1 0 0.01 0 M6 24h36 M24 6c-9 8-9 28 0 36 M24 6c9 8 9 28 0 36",
  pin: "M24 42 C14 28 12 24 12 19 a12 12 0 0 1 24 0 c0 5 -2 9 -12 23 M24 15 a4 4 0 1 0 0.01 0", shield: "M24 6 L40 12 V24 C40 33 33 40 24 43 C15 40 8 33 8 24 V12 Z M17 24 L22 29 L32 18",
  cloud: "M14 34 a8 8 0 0 1 -1 -16 a11 11 0 0 1 21 3 a6.5 6.5 0 0 1 0 13 Z", lock: "M12 22 H36 V40 H12 Z M17 22 V15 a7 7 0 0 1 14 0 V22 M24 29 V34",
  gear: "M24 16a8 8 0 1 0 0.01 0 M24 4 V10 M24 38 V44 M4 24 H10 M38 24 H44 M10 10 L14 14 M34 34 L38 38 M38 10 L34 14 M14 34 L10 38",
  user: "M24 22a8 8 0 1 0 0.01 0 M8 42 C8 32 16 28 24 28 C32 28 40 32 40 42", code: "M18 14 L8 24 L18 34 M30 14 L40 24 L30 34 M27 10 L21 38",
  fiber: "M4 30 C14 30 14 14 24 14 C34 14 34 34 44 34 M4 24 C14 24 14 20 24 20 C34 20 34 28 44 28", q: "M16 18 a8 8 0 1 1 12 7 c-3 2 -4 3 -4 7 M24 40 V41",
  doc: "M12 6 H29 L38 15 V42 H12 Z M29 6 V15 H38 M18 24 H32 M18 31 H32", cap: "M4 18 L24 8 L44 18 L24 28 Z M12 23 V33 C18 38 30 38 36 33 V23",
  star: "M24 6 L29 19 L43 20 L32 29 L36 43 L24 35 L12 43 L16 29 L5 20 L19 19 Z", trash: "M10 14 H38 M18 14 V8 H30 V14 M14 14 L16 42 H32 L34 14",
  phone: "M16 4 H32 a4 4 0 0 1 4 4 V40 a4 4 0 0 1 -4 4 H16 a4 4 0 0 1 -4 -4 V8 a4 4 0 0 1 4 -4 Z M21 38 H27",
};

export const Seal: React.FC<{ size: number; color?: string }> = ({ size, color = C.hero }) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <circle cx="50" cy="50" r="46" fill="none" stroke={color} strokeWidth="3" strokeDasharray="4 3" />
    <circle cx="50" cy="50" r="34" fill={color} opacity="0.85" />
    <path d="M32 52 L45 64 L69 38" fill="none" stroke={C.paper} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const Cert: React.FC<{ w: number; h: number; title?: string; sub?: string; ok?: boolean; seal?: boolean; dim?: boolean }> = ({ w, h, title = "জন্ম নিবন্ধন সনদ", sub = "Birth Registration", seal = true, dim }) => (
  <div style={{ width: w, height: h, borderRadius: 18, background: C.paper, position: "relative", boxShadow: `0 28px 60px -18px ${C.shadow}`, filter: dim ? "saturate(0.4) brightness(0.8)" : undefined, overflow: "hidden" }}>
    <div style={{ position: "absolute", inset: 14, border: `3px double ${C.accentDim}`, borderRadius: 10 }} />
    <div style={{ position: "absolute", left: 0, top: 0, width: w, height: h * 0.2, background: C.accentDim, opacity: 0.9 }} />
    <div style={{ position: "absolute", left: 0, top: h * 0.035, width: w, textAlign: "center", color: C.text, fontFamily: theme.fonts.sans, fontSize: h * 0.085, fontWeight: 700, ...heavy(h * 0.085) }}>{title}</div>
    <div style={{ position: "absolute", left: 0, top: h * 0.235, width: w, textAlign: "center", color: C.ink, fontFamily: theme.fonts.mono, fontSize: h * 0.05, opacity: 0.7 }}>{sub}</div>
    {[0.34, 0.45, 0.56, 0.67].map((y, i) => (
      <div key={i} style={{ position: "absolute", left: w * 0.12, top: h * y, width: w * (i % 2 ? 0.55 : 0.7), height: h * 0.03, borderRadius: 6, background: "rgba(20,32,26,0.22)" }} />
    ))}
    {seal && <div style={{ position: "absolute", right: w * 0.08, bottom: h * 0.07 }}><Seal size={h * 0.24} /></div>}
  </div>
);

export const Stamp: React.FC<{ text: string; size: number; color?: string; rot?: number }> = ({ text, size, color = C.hero, rot = -12 }) => (
  <div style={{ display: "inline-block", padding: `${size * 0.1}px ${size * 0.35}px`, border: `${Math.max(5, size * 0.09)}px solid ${color}`, borderRadius: size * 0.2, color, fontFamily: theme.fonts.sans, fontSize: size, fontWeight: 700, transform: `rotate(${rot}deg)`, background: "rgba(7,19,15,0.35)", ...heavy(size), letterSpacing: 0 }}>{text}</div>
);

export const NidCard: React.FC<{ w: number; h: number; name?: string; father?: string; wrong?: number; ok?: number; wrongF?: number; okF?: number; tag?: string; chip?: boolean }> = ({ w, h, name, father, wrong = 0, ok = 0, wrongF = 0, okF = 0, tag = "স্মার্ট NID", chip = true }) => (
  <div style={{ width: w, height: h, borderRadius: h * 0.08, position: "relative", overflow: "hidden", background: `linear-gradient(140deg, #1E9A6E, ${C.accentDim} 38%, #0E3B2B)`, border: `2px solid rgba(255,255,255,0.25)`, boxShadow: `0 28px 60px -18px ${C.shadow}` }}>
    <div style={{ position: "absolute", left: 0, top: 0, width: w, height: h * 0.2, background: "rgba(0,0,0,0.28)" }} />
    <div style={{ position: "absolute", left: w * 0.05, top: h * 0.035, color: C.text, fontFamily: theme.fonts.sans, fontSize: h * 0.1, fontWeight: 700, ...heavy(h * 0.1) }}>{tag}</div>
    <div style={{ position: "absolute", right: w * 0.05, top: h * 0.04, width: h * 0.12, height: h * 0.12, borderRadius: "50%", background: C.hero, boxShadow: "0 0 0 4px rgba(242,248,244,0.9)" }} />
    {chip && <div style={{ position: "absolute", left: w * 0.06, top: h * 0.3, width: w * 0.14, height: h * 0.18, borderRadius: 8, background: `linear-gradient(135deg, ${C.warn}, #B8892A)`, border: "2px solid rgba(0,0,0,0.25)" }} />}
    <div style={{ position: "absolute", right: w * 0.06, top: h * 0.27, width: w * 0.24, height: h * 0.4, borderRadius: 10, background: "rgba(7,19,15,0.35)", display: "flex", alignItems: "flex-end", justifyContent: "center", overflow: "hidden" }}>
      <svg width={w * 0.2} height={h * 0.34} viewBox="0 0 48 48"><circle cx="24" cy="16" r="9" fill={C.dim} opacity="0.8" /><path d="M6 48 C6 33 16 28 24 28 C32 28 42 33 42 48 Z" fill={C.dim} opacity="0.8" /></svg>
    </div>
    <div style={{ position: "absolute", left: w * 0.06, top: h * 0.54, width: w * 0.58 }}>
      <div style={{ fontFamily: theme.fonts.mono, fontSize: h * 0.06, color: "rgba(242,248,244,0.75)" }}>নাম / Name</div>
      <div style={{ fontFamily: theme.fonts.sans, fontSize: h * 0.098, fontWeight: 700, color: wrong ? "#FFD3D8" : C.text, lineHeight: 1.15, background: wrong ? "rgba(244,42,65,0.45)" : ok ? "rgba(46,204,143,0.35)" : undefined, borderRadius: 6, padding: "0 6px", margin: "0 -6px", whiteSpace: "nowrap", ...heavy(h * 0.098) }}>{name ?? "- - - - - -"}</div>
    </div>
    <div style={{ position: "absolute", left: w * 0.06, top: h * 0.765, width: w * 0.62 }}>
      <div style={{ fontFamily: theme.fonts.mono, fontSize: h * 0.06, color: "rgba(242,248,244,0.75)" }}>পিতা / Father</div>
      <div style={{ fontFamily: theme.fonts.sans, fontSize: h * 0.088, fontWeight: 700, color: wrongF ? "#FFD3D8" : C.text, lineHeight: 1.15, background: wrongF ? "rgba(244,42,65,0.45)" : okF ? "rgba(46,204,143,0.35)" : undefined, borderRadius: 6, padding: "0 6px", margin: "0 -6px", whiteSpace: "nowrap", ...heavy(h * 0.088) }}>{father ?? "- - - - - -"}</div>
    </div>
  </div>
);

export const Note: React.FC<{ w: number; h?: number; amount?: string }> = ({ w, h = w * 0.45, amount = "১০০" }) => (
  <div style={{ width: w, height: h, borderRadius: h * 0.1, position: "relative", background: `linear-gradient(120deg, #9ADBB8, #5DBA8C)`, border: `3px solid ${C.accentDim}`, boxShadow: `0 18px 34px -10px ${C.shadow}`, overflow: "hidden" }}>
    <div style={{ position: "absolute", inset: h * 0.08, border: `2px dashed ${C.accentDim}`, borderRadius: h * 0.06 }} />
    <div style={{ position: "absolute", left: w * 0.06, top: h * 0.12, fontFamily: theme.fonts.sans, fontSize: h * 0.34, fontWeight: 700, color: "#0E3B2B", ...heavy(h * 0.34) }}>{amount}</div>
    <div style={{ position: "absolute", right: w * 0.08, top: h * 0.2, width: h * 0.5, height: h * 0.5, borderRadius: "50%", border: `3px solid ${C.accentDim}`, opacity: 0.7 }} />
    <div style={{ position: "absolute", left: w * 0.08, bottom: h * 0.1, fontFamily: theme.fonts.sans, fontSize: h * 0.17, fontWeight: 700, color: "#0E3B2B" }}>টাকা</div>
  </div>
);

export const Db: React.FC<{ w: number; h: number; color?: string; label?: string; dim?: boolean }> = ({ w, h, color = C.accent, label, dim }) => (
  <div style={{ width: w, height: h, position: "relative", opacity: dim ? 0.5 : 1 }}>
    <svg width={w} height={h} viewBox="0 0 100 120" style={{ filter: `drop-shadow(0 0 16px ${color}55)` }}>
      <path d="M8 22 V92 C8 106 92 106 92 92 V22" fill={C.panel2} stroke={color} strokeWidth="3" />
      <ellipse cx="50" cy="22" rx="42" ry="14" fill={C.panel} stroke={color} strokeWidth="3" />
      <path d="M8 46 C8 60 92 60 92 46 M8 70 C8 84 92 84 92 70" fill="none" stroke={color} strokeWidth="2.5" opacity="0.8" />
    </svg>
    {label && <div style={{ position: "absolute", left: -40, width: w + 80, top: h + 8, textAlign: "center", fontFamily: theme.fonts.sans, fontSize: 36, fontWeight: 700, color: C.text, ...heavy(36) }}>{label}</div>}
  </div>
);

export const Server: React.FC<{ w: number; h: number; color?: string; led?: string; units?: number; blink?: number }> = ({ w, h, color = C.accent, led = C.accent, units = 4, blink = 0 }) => (
  <div style={{ width: w, height: h, borderRadius: 18, background: `linear-gradient(180deg, ${C.panel2}, ${C.panel})`, border: `3px solid ${color}`, boxShadow: `0 0 30px ${color}44, 0 24px 40px -14px ${C.shadow}`, padding: h * 0.07, display: "flex", flexDirection: "column", gap: h * 0.05 }}>
    {Array.from({ length: units }).map((_, i) => (
      <div key={i} style={{ flex: 1, borderRadius: 8, background: "rgba(7,19,15,0.65)", border: `1.5px solid ${C.line}`, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 14px" }}>
        <div style={{ width: "55%", height: 8, borderRadius: 4, background: "rgba(242,248,244,0.18)" }} />
        <div style={{ width: 14, height: 14, borderRadius: "50%", background: led, opacity: blink ? 0.35 + 0.65 * Math.abs(Math.sin((blink + i * 3) / 4)) : 1, boxShadow: `0 0 12px ${led}` }} />
      </div>
    ))}
  </div>
);

export const Laptop: React.FC<{ w: number; color?: string; locked?: boolean; sh?: number }> = ({ w, color = C.accent, sh = 0.62 }) => (
  <div style={{ width: w, height: w * 0.7, position: "relative" }}>
    <div style={{ position: "absolute", left: w * 0.1, top: 0, width: w * 0.8, height: w * sh * 0.8, borderRadius: w * 0.04, background: C.bg, border: `${w * 0.025}px solid ${C.panel2}`, boxShadow: `0 0 24px ${color}33` }}>
      <div style={{ position: "absolute", inset: "14%", borderRadius: 6, background: `linear-gradient(135deg, ${color}55, transparent)` }} />
    </div>
    <div style={{ position: "absolute", left: 0, top: w * sh * 0.8, width: w, height: w * 0.06, borderRadius: `0 0 ${w * 0.05}px ${w * 0.05}px`, background: `linear-gradient(180deg, ${C.dim}, ${C.panel2})` }} />
  </div>
);

export const Padlock: React.FC<{ size: number; color?: string; shut?: number }> = ({ size, color = C.hero, shut = 1 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" style={{ filter: `drop-shadow(0 0 ${size * 0.2}px ${color}66)` }}>
    <path d={`M16 22 V${15 - (1 - shut) * 8} a8 8 0 0 1 16 0 V22`} fill="none" stroke={color} strokeWidth="4.5" strokeLinecap="round" />
    <rect x="10" y="22" width="28" height="20" rx="4" fill={color} />
    <circle cx="24" cy="31" r="3" fill={C.bg} /><rect x="23" y="31" width="2" height="6" fill={C.bg} />
  </svg>
);

export const Brick: React.FC<{ w: number; h: number; c?: string }> = ({ w, h, c = C.hero }) => (
  <div style={{ width: w, height: h, borderRadius: 4, background: c, border: `2px solid rgba(0,0,0,0.3)`, boxShadow: "inset 0 -4px 0 rgba(0,0,0,0.25)" }} />
);

export const Building: React.FC<{ w: number; floors: number; shown?: number; color?: string; sign?: string; empty?: boolean }> = ({ w, floors, shown = floors, color = C.hero, sign, empty }) => {
  const fh = 64;
  return (
    <div style={{ width: w, height: floors * fh + 40, position: "relative" }}>
      {Array.from({ length: floors }).map((_, i) => {
        const idx = floors - 1 - i; // bottom = 0
        const vis = clamp01(shown - idx);
        return (
          <div key={i} style={{ position: "absolute", left: 0, top: i * fh + 40 - (1 - vis) * 40, width: w, height: fh - 4, opacity: vis, borderRadius: 6, background: `linear-gradient(180deg, #6C7F77, #4C5E56)`, border: "2px solid rgba(0,0,0,0.3)", display: "flex", justifyContent: "space-around", alignItems: "center", padding: "0 14px" }}>
            {Array.from({ length: 5 }).map((_, k) => <div key={k} style={{ width: w * 0.1, height: fh * 0.5, borderRadius: 4, background: empty ? "rgba(7,19,15,0.85)" : C.warn, opacity: empty ? 1 : 0.85 }} />)}
          </div>
        );
      })}
      <div style={{ position: "absolute", left: -12, top: 18 + Math.max(0, floors - Math.ceil(shown)) * fh, width: w + 24, height: 26, borderRadius: 6, background: color }} />
      {sign && <div style={{ position: "absolute", left: 0, top: -34, width: w, textAlign: "center", fontFamily: theme.fonts.sans, fontSize: 30, fontWeight: 700, color: C.text }}>{sign}</div>}
    </div>
  );
};
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

export const Gauge: React.FC<{ size: number; p: number; label?: string }> = ({ size, p, label }) => {
  const a = -120 + p * 240;
  const col = p < 0.5 ? C.cool : p < 0.8 ? C.warn : C.hero; // functional heat colors
  const arc = (from: number, to: number) => { const r = 40, f = (d: number) => [50 + r * Math.cos(((d - 90) * Math.PI) / 180), 50 + r * Math.sin(((d - 90) * Math.PI) / 180)]; const [x1, y1] = f(from), [x2, y2] = f(to); return `M${x1} ${y1} A${r} ${r} 0 ${to - from > 180 ? 1 : 0} 1 ${x2} ${y2}`; };
  return (
    <div style={{ width: size, height: size * 0.8, position: "relative" }}>
      <svg width={size} height={size} viewBox="0 0 100 100">
        <path d={arc(-120, 120)} fill="none" stroke={C.line} strokeWidth="9" strokeLinecap="round" />
        <path d={arc(-120, a)} fill="none" stroke={col} strokeWidth="9" strokeLinecap="round" />
        <line x1="50" y1="50" x2={50 + 32 * Math.cos(((a - 90) * Math.PI) / 180)} y2={50 + 32 * Math.sin(((a - 90) * Math.PI) / 180)} stroke={C.text} strokeWidth="3" strokeLinecap="round" />
        <circle cx="50" cy="50" r="5" fill={C.text} />
      </svg>
      {label && <div style={{ position: "absolute", left: 0, width: size, top: size * 0.62, textAlign: "center", fontFamily: theme.fonts.mono, fontSize: size * 0.12, color: col }}>{label}</div>}
    </div>
  );
};

export const BigNum: React.FC<{ v: number; size: number; color?: string; suffix?: string; comma?: boolean }> = ({ v, size, color = C.text, suffix, comma = true }) => {
  const s = comma ? Math.round(v).toLocaleString("en-US") : String(Math.round(v));
  return <div style={{ fontFamily: theme.fonts.sans, fontSize: size, fontWeight: 700, color, lineHeight: 1.1, whiteSpace: "nowrap", ...heavy(size) }}>{bn(s)}{suffix}</div>;
};

export const Gear: React.FC<{ size: number; color?: string }> = ({ size, color = C.accent }) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    {Array.from({ length: 8 }).map((_, i) => <rect key={i} x="43" y="4" width="14" height="22" rx="3" fill={color} transform={`rotate(${i * 45} 50 50)`} />)}
    <circle cx="50" cy="50" r="30" fill={color} /><circle cx="50" cy="50" r="12" fill={C.bg} />
  </svg>
);
