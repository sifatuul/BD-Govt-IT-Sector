// Soft, quiet synthesized SFX kit -> public/sfx/*.wav (16-bit mono 44.1k). Deterministic.
import fs from "node:fs";
const SR = 44100;
let seed = 12345;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const buf = (d) => new Float32Array(Math.floor(d * SR));
const lp = (x, fc) => { const a = 1 - Math.exp((-2 * Math.PI * fc) / SR); let y = 0; return x.map((v) => (y += a * (v - y))); };
const lpVar = (x, fn) => { let y = 0; return x.map((v, i) => { const a = 1 - Math.exp((-2 * Math.PI * fn(i / x.length)) / SR); return (y += a * (v - y)); }); };
const hp = (x, fc) => { const l = lp(x, fc); return x.map((v, i) => v - l[i]); };
const env = (n, a, r) => (i) => { const t = i / SR, T = n / SR; return Math.min(1, t / a) * Math.min(1, (T - t) / r); };
const sm = (v) => v * v * (3 - 2 * v);
function norm(x, peak) { let m = 0; for (const v of x) m = Math.max(m, Math.abs(v)); const g = peak / (m || 1); const e = Math.floor(0.012 * SR); return x.map((v, i) => v * g * Math.min(1, i / e, (x.length - i) / e)); }
function write(name, x) {
  const b = Buffer.alloc(44 + x.length * 2);
  b.write("RIFF", 0); b.writeUInt32LE(36 + x.length * 2, 4); b.write("WAVEfmt ", 8); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22);
  b.writeUInt32LE(SR, 24); b.writeUInt32LE(SR * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write("data", 36); b.writeUInt32LE(x.length * 2, 40);
  x.forEach((v, i) => b.writeInt16LE(Math.max(-32767, Math.min(32767, Math.round(v * 32767))), 44 + i * 2));
  fs.writeFileSync(`public/sfx/${name}.wav`, b);
}
const sine = (n, f) => { let ph = 0; return Float32Array.from({ length: n }, (_, i) => { ph += (2 * Math.PI * f(i / SR)) / SR; return Math.sin(ph); }); };
const kit = {};
// whoosh: airy noise, cutoff sweeps up then down, smooth bell envelope
{ const n = Math.floor(0.6 * SR); let x = Float32Array.from({ length: n }, rnd); x = lpVar(x, (t) => 250 + 1900 * Math.sin(Math.PI * t) ** 1.5); x = hp(x, 180);
  kit.whoosh = norm(x.map((v, i) => v * sm(Math.sin((Math.PI * i) / n))), 0.5); }
// pop: soft sine drop
{ const n = Math.floor(0.2 * SR); const s = sine(n, (t) => 240 + 260 * Math.exp(-t * 28)); kit.pop = norm(lp(s.map((v, i) => v * Math.exp(-(i / SR) * 18)), 2500), 0.55); }
// tick: tiny soft click
{ const n = Math.floor(0.09 * SR); const s = sine(n, () => 1100); kit.tick = norm(lp(s.map((v, i) => v * Math.exp(-(i / SR) * 70)), 3000), 0.4); }
// thud: low body hit
{ const n = Math.floor(0.5 * SR); const s = sine(n, (t) => 48 + 60 * Math.exp(-t * 22)); const nz = lp(Float32Array.from({ length: n }, (_, i) => rnd() * Math.exp(-(i / SR) * 90)), 500);
  kit.thud = norm(s.map((v, i) => v * Math.exp(-(i / SR) * 9) + nz[i] * 0.5), 0.6); }
// stamp: thud + soft paper slap
{ const n = Math.floor(0.4 * SR); const s = sine(n, (t) => 70 + 80 * Math.exp(-t * 30)); const nz = lp(Float32Array.from({ length: n }, (_, i) => rnd() * Math.exp(-(i / SR) * 55)), 1400);
  kit.stamp = norm(s.map((v, i) => v * Math.exp(-(i / SR) * 14) + nz[i] * 0.8), 0.55); }
// ding: gentle bell
{ const n = Math.floor(1.0 * SR); const a = sine(n, () => 784), b = sine(n, () => 1176), c = sine(n, () => 1568);
  kit.ding = norm(a.map((v, i) => { const t = i / SR; return (v + 0.3 * b[i] + 0.12 * c[i]) * Math.min(1, t / 0.008) * Math.exp(-t * 4.2); }), 0.45); }
// coin: two soft metallic tings
{ const n = Math.floor(0.55 * SR); const a = sine(n, () => 1318), b = sine(n, () => 1760);
  kit.coin = norm(Float32Array.from({ length: n }, (_, i) => { const t = i / SR; return a[i] * Math.exp(-t * 11) * Math.min(1, t / 0.004) * 0.7 + (t > 0.07 ? b[i] * Math.exp(-(t - 0.07) * 9) : 0); }), 0.4); }
// paper: soft rustle
{ const n = Math.floor(0.45 * SR); let x = Float32Array.from({ length: n }, rnd); x = hp(lp(x, 3200), 700);
  kit.paper = norm(x.map((v, i) => { const t = i / n; return v * sm(Math.sin(Math.PI * t)) * (0.55 + 0.45 * Math.abs(Math.sin(t * 38))); }), 0.4); }
// buzz: low soft error tone (not harsh)
{ const n = Math.floor(0.38 * SR); const a = sine(n, () => 110), b = sine(n, () => 165);
  kit.buzz = norm(lp(a.map((v, i) => (v + 0.5 * b[i]) * (0.7 + 0.3 * Math.sin(i / SR * 2 * Math.PI * 14)) * sm(Math.min(1, (i / SR) / 0.02)) * Math.min(1, (n - i) / (0.1 * SR))), 700), 0.5); }
// swell: soft riser
{ const n = Math.floor(1.3 * SR); let x = Float32Array.from({ length: n }, rnd); x = lpVar(x, (t) => 200 + 1500 * t * t);
  const s = sine(n, (t) => 160 + 140 * t); kit.swell = norm(x.map((v, i) => (v * 0.8 + s[i] * 0.4) * sm(i / n) * Math.min(1, (n - i) / (0.15 * SR))), 0.45); }
// beep: tiny UI confirm
{ const n = Math.floor(0.16 * SR); const s = sine(n, () => 660); kit.beep = norm(s.map((v, i) => v * Math.min(1, i / SR / 0.006) * Math.exp(-(i / SR) * 16)), 0.4); }
for (const [k, v] of Object.entries(kit)) write(k, v);
console.log("sfx:", Object.keys(kit).join(", "));
