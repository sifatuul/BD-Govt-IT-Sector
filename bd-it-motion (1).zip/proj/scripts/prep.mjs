import { execFileSync } from "node:child_process";
for (const s of ["parse-srt", "embed-fonts", "make-sfx"]) execFileSync("node", [`scripts/${s}.mjs`], { stdio: "inherit" });
