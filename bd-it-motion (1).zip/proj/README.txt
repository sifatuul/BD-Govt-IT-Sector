IT Sector Motion Graphics (Bangla) - Remotion 4.0.528, 1920x1080, 30 fps
Colour scheme: Bangladesh Night (bg #07130F, hero #F42A41, accent #2ECC8F, text #F2F8F4)

PREVIEW:   npm install   then   npm run dev     (Studio plays public/voiceover.mp3 automatically)
RENDER:    double-click RENDER.bat  (renders with voiceover -> out/video.mp4)
           or: npx remotion render src/index.ts Main out/video.mp4 --props=props-voiceover.json
TYPECHECK: npm run tsc
REGENERATE timing/fonts/SFX: npm run prep   (SRT -> src/timing.ts, fonts -> src/fontData.ts, SFX -> public/sfx)

Timing: everything is derived from public/script.srt (src/anchors.ts). To change the voiceover/SRT, replace
public/voiceover.mp3 + public/script.srt and run npm run prep.
Credit scene: src/components/Credit.tsx (CREDIT name/tag, SCALE = 0.4). Photo: public/creator.png.
Subtitle phrases: src/headlines.ts. SFX cue sheet + volumes: src/sfx.ts. Colours/fonts/springs: src/theme.ts.

FONT NOTE: the bundled Bengali font is FreeSans (embedded as base64, no network). For a nicer Bengali look put
HindSiliguri-Regular.ttf / -Medium.ttf / -Bold.ttf into public/fonts/ and run npm run prep (auto-preferred).
